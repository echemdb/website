# nishihara_1995_underpotential_75_f5a_solid

A cyclic voltammogram for
Pt(10,9,9)
from Figure 5a in

C. nishihara et al. Underpotential deposition of copper on Pt(S)-[n(111)×(100)] electrodes in sulfuric acid solution. Journal of Electroanalytical Chemistry, 386(1-2):75–82, 1995

https://doi.org/10.1016/0022-0728(94)03803-B

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/nishihara_1995_underpotential_75_f5a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `nishihara_1995_underpotential_75_f5a_solid.csv`: the digitized data.
* `nishihara_1995_underpotential_75_f5a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("nishihara_1995_underpotential_75_f5a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{nishihara_1995_underpotential_75,
    author = "nishihara, Chizuko and Nozoye, Hisakazu",
    title = "Underpotential deposition of copper on Pt(S)-[n(111)$\times$(100)] electrodes in sulfuric acid solution",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "386",
    number = "1-2",
    pages = "75--82",
    year = "1995",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(94)03803-B"
}

```