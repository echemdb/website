# endres_2006_probing_1377_f11_b

A cyclic voltammogram for
Au(111)
from Figure 11 in

F. Endres et al. Probing lithium and alumina impurities in air-and water stable ionic liquids by cyclic voltammetry and in situ scanning tunneling microscopy. Zeitschrift für Physikalische Chemie, 220(10):1377–1394, 2006

https://doi.org/10.1524/zpch.2006.220.10.1377

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/endres_2006_probing_1377_f11_b/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `endres_2006_probing_1377_f11_b.csv`: the digitized data.
* `endres_2006_probing_1377_f11_b.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("endres_2006_probing_1377_f11_b.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{endres_2006_probing_1377,
    author = "Endres, Frank and El Abedin, Sherif Zein and Borissenko, Natalia",
    title = "Probing lithium and alumina impurities in air-and water stable ionic liquids by cyclic voltammetry and in situ scanning tunneling microscopy",
    journal = "Zeitschrift für Physikalische Chemie",
    volume = "220",
    number = "10",
    pages = "1377--1394",
    year = "2006",
    publisher = "De Gruyter Oldenbourg",
    doi = "10.1524/zpch.2006.220.10.1377"
}

```