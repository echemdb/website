# schuett_2021_electrodeposition_20624_fs1_blue

A cyclic voltammogram for
Au(111)
from Figure S1 in

F. M. Schuett et al. Electrodeposition of zinc onto Au(111) and Au(100) from the ionic liquid [MPPip][TFSI]. Angewandte Chemie, 133(37):20624–20631, 2021

https://doi.org/10.1002/anie.202107195

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/schuett_2021_electrodeposition_20624_fs1_blue/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `schuett_2021_electrodeposition_20624_fs1_blue.csv`: the digitized data.
* `schuett_2021_electrodeposition_20624_fs1_blue.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("schuett_2021_electrodeposition_20624_fs1_blue.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{schuett_2021_electrodeposition_20624,
    author = "Schuett, Fabian M and Heubach, Maren-Kathrin and Mayer, Jerome and Ceblin, Maximilian U and Kibler, Ludwig A and Jacob, Timo",
    title = "Electrodeposition of zinc onto Au(111) and Au(100) from the ionic liquid [MPPip][TFSI]",
    journal = "Angewandte Chemie",
    volume = "133",
    number = "37",
    pages = "20624--20631",
    year = "2021",
    publisher = "Wiley Online Library",
    doi = "10.1002/anie.202107195"
}

```