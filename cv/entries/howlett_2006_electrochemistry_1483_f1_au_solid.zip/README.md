# howlett_2006_electrochemistry_1483_f1_au_solid

A cyclic voltammogram for
Au(poly)
from Figure 1 in

P. C. Howlett et al. Electrochemistry at negative potentials in bis(trifluoromethanesulfonyl)amide ionic liquids. Zeitschrift für Physikalische Chemie, 220(10):1483–1498, 2006

https://doi.org/10.1524/zpch.2006.220.10.1483

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/howlett_2006_electrochemistry_1483_f1_au_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `howlett_2006_electrochemistry_1483_f1_au_solid.csv`: the digitized data.
* `howlett_2006_electrochemistry_1483_f1_au_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("howlett_2006_electrochemistry_1483_f1_au_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{howlett_2006_electrochemistry_1483,
    author = "Howlett, Patrick C and Izgorodina, Ekaterina I and Forsyth, Maria and MacFarlane, Douglas R",
    title = "Electrochemistry at negative potentials in bis(trifluoromethanesulfonyl)amide ionic liquids",
    journal = "Zeitschrift für Physikalische Chemie",
    volume = "220",
    number = "10",
    pages = "1483--1498",
    year = "2006",
    publisher = "De Gruyter Oldenbourg",
    doi = "10.1524/zpch.2006.220.10.1483"
}

```