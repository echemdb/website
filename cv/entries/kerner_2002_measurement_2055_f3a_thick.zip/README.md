# kerner_2002_measurement_2055_f3a_thick

A cyclic voltammogram for
Au(111)
from Figure 3a in

Z. Kerner et al. Measurement of adsorption rates of anions on Au(111) electrodes by impedance spectroscopy. Electrochimica acta, 47(13-14):2055–2063, 2002

https://doi.org/10.1016/0022-0728(92)80223-Q

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/kerner_2002_measurement_2055_f3a_thick/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `kerner_2002_measurement_2055_f3a_thick.csv`: the digitized data.
* `kerner_2002_measurement_2055_f3a_thick.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("kerner_2002_measurement_2055_f3a_thick.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{kerner_2002_measurement_2055,
    author = "Kerner, Zsolt and Pajkossy, Tamás",
    title = "Measurement of adsorption rates of anions on Au(111) electrodes by impedance spectroscopy",
    journal = "Electrochimica acta",
    volume = "47",
    number = "13-14",
    pages = "2055--2063",
    year = "2002",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(92)80223-Q"
}

```