# ocko_1996_halide_55_f6a_solid

A cyclic voltammogram for
Ag(100)
from Figure 6a in

B. Ocko et al. Halide electroadsorption on single crystal surfaces. MRS Online Proceedings Library (OPL), 451:55–67, 1996

https://doi.org/10.1557/PROC-451-55

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/ocko_1996_halide_55_f6a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `ocko_1996_halide_55_f6a_solid.csv`: the digitized data.
* `ocko_1996_halide_55_f6a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("ocko_1996_halide_55_f6a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{ocko_1996_halide_55,
    author = "Ocko, BM and Wandlowski, Th",
    title = "Halide electroadsorption on single crystal surfaces",
    journal = "MRS Online Proceedings Library (OPL)",
    volume = "451",
    pages = "55--67",
    year = "1996",
    publisher = "Cambridge University Press",
    doi = "10.1557/PROC-451-55"
}

```