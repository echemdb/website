# bonhote_1996_hydrophobic_1168_f7_dotdashed

A cyclic voltammogram for
Au(111)
from Figure 7 in

P. Bonhote et al. Hydrophobic, highly conductive ambient-temperature molten salts. Inorganic chemistry, 35(5):1168–1178, 1996

https://doi.org/10.1021/ic951325x

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/bonhote_1996_hydrophobic_1168_f7_dotdashed/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `bonhote_1996_hydrophobic_1168_f7_dotdashed.csv`: the digitized data.
* `bonhote_1996_hydrophobic_1168_f7_dotdashed.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("bonhote_1996_hydrophobic_1168_f7_dotdashed.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{bonhote_1996_hydrophobic_1168,
    author = "Bonhote, Pierre and Dias, Ana-Paula and Papageorgiou, Nicholas and Kalyanasundaram, Kuppuswamy and Grätzel, Michael",
    title = "Hydrophobic, highly conductive ambient-temperature molten salts",
    journal = "Inorganic chemistry",
    volume = "35",
    number = "5",
    pages = "1168--1178",
    year = "1996",
    publisher = "ACS Publications",
    doi = "10.1021/ic951325x"
}

```