# liu_2019_in-situ_11_f2_dashed

A cyclic voltammogram for
Au(111)
from Figure 2 in

S. Liu et al. In-situ STM and AFM studies on electrochemical interfaces in imidazolium-based ionic liquids. Electrochimica Acta, 309:11–17, 2019

https://doi.org/10.1016/j.electacta.2019.04.066

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/liu_2019_in-situ_11_f2_dashed/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `liu_2019_in-situ_11_f2_dashed.csv`: the digitized data.
* `liu_2019_in-situ_11_f2_dashed.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("liu_2019_in-situ_11_f2_dashed.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{liu_2019_in-situ_11,
    author = "Liu, Shuai and Peng, Jin and Chen, Li and Sebastián, Paula and Feliu, Juan M and Yan, Jiawei and Mao, Bingwei",
    title = "In-situ STM and AFM studies on electrochemical interfaces in imidazolium-based ionic liquids",
    journal = "Electrochimica Acta",
    volume = "309",
    pages = "11--17",
    year = "2019",
    publisher = "Elsevier",
    doi = "10.1016/j.electacta.2019.04.066"
}

```