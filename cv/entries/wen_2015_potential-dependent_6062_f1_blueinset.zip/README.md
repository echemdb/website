# wen_2015_potential-dependent_6062_f1_blueinset

A cyclic voltammogram for
Au(111)
from Figure 1 in

R. Wen et al. Potential-Dependent Adlayer Structure and Dynamics at the Ionic Liquid/Au(111) Interface: A Molecular-Scale In Situ Video-STM Study. Angewandte Chemie International Edition, 54(20):6062–6066, 2015

https://doi.org/10.1002/anie.201501715

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wen_2015_potential-dependent_6062_f1_blueinset/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wen_2015_potential-dependent_6062_f1_blueinset.csv`: the digitized data.
* `wen_2015_potential-dependent_6062_f1_blueinset.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wen_2015_potential-dependent_6062_f1_blueinset.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wen_2015_potential-dependent_6062,
    author = "Wen, Rui and Rahn, Björn and Magnussen, Olaf M",
    title = "Potential-Dependent Adlayer Structure and Dynamics at the Ionic Liquid/Au(111) Interface: A Molecular-Scale In Situ Video-STM Study",
    journal = "Angewandte Chemie International Edition",
    volume = "54",
    number = "20",
    pages = "6062--6066",
    year = "2015",
    publisher = "Wiley Online Library",
    doi = "10.1002/anie.201501715"
}

```