# kibler_2003_preparation_1_f5-2-1c_solid

A cyclic voltammogram for
Au(110)
from Figure 5-2-1c in

L. A. Kibler. Preparation and characterization of noble metal single crystal electrode surfaces. International Society of Electrochemistry, 2003

https://www.uni-ulm.de/fileadmin/website_uni_ulm/nawi.inst.080/mitarbeiter/Kibler/KiblerSingleCrystals2003.pdf

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/kibler_2003_preparation_1_f5-2-1c_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `kibler_2003_preparation_1_f5-2-1c_solid.csv`: the digitized data.
* `kibler_2003_preparation_1_f5-2-1c_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("kibler_2003_preparation_1_f5-2-1c_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@book{kibler_2003_preparation_1,
    author = "Kibler, Ludwig A",
    title = "Preparation and characterization of noble metal single crystal electrode surfaces",
    publisher = "International Society of Electrochemistry",
    pages = "1--20",
    year = "2003"
}

```