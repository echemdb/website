# pajkossy_2001_double_3063_f6a_solid

A cyclic voltammogram for
Pt(111)
from Figure 6a in

T. Pajkossy et al. Double layer capacitance of Pt(111) single crystal electrodes. Electrochimica acta, 46(20-21):3063–3071, 2001

https://doi.org/10.1016/S0013-4686(01)00597-7

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/pajkossy_2001_double_3063_f6a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `pajkossy_2001_double_3063_f6a_solid.csv`: the digitized data.
* `pajkossy_2001_double_3063_f6a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("pajkossy_2001_double_3063_f6a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{pajkossy_2001_double_3063,
    author = "Pajkossy, T and Kolb, DM",
    title = "Double layer capacitance of Pt(111) single crystal electrodes",
    journal = "Electrochimica acta",
    volume = "46",
    number = "20-21",
    pages = "3063--3071",
    year = "2001",
    publisher = "Elsevier",
    doi = "10.1016/S0013-4686(01)00597-7"
}

```