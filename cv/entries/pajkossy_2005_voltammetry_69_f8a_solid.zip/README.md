# pajkossy_2005_voltammetry_69_f8a_solid

A cyclic voltammogram for
Ir(111)
from Figure 8a in

T. Pajkossy et al. Voltammetry and impedance measurements of Ir(111) electrodes in aqueous solutions. Journal of Electroanalytical Chemistry, 582(1-2):69–75, 2005

https://doi.org/10.1016/j.jelechem.2005.03.019

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/pajkossy_2005_voltammetry_69_f8a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `pajkossy_2005_voltammetry_69_f8a_solid.csv`: the digitized data.
* `pajkossy_2005_voltammetry_69_f8a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("pajkossy_2005_voltammetry_69_f8a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{pajkossy_2005_voltammetry_69,
    author = "Pajkossy, T and Kibler, LA and Kolb, DM",
    title = "Voltammetry and impedance measurements of Ir(111) electrodes in aqueous solutions",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "582",
    number = "1-2",
    pages = "69--75",
    year = "2005",
    publisher = "Elsevier",
    doi = "10.1016/j.jelechem.2005.03.019"
}

```