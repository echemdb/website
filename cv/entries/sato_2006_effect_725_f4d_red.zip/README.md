# sato_2006_effect_725_f4d_red

A cyclic voltammogram for
Au(111)
from Figure 4d in

K. Sato et al. Effect of Sulfuric Acid Concentration on the Structure of Sulfate Adlayer on Au(111) Electrode. Electrochemistry Communications, 8(5):725–730, May 2006

https://doi.org/10.1016/j.elecom.2006.03.001

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/sato_2006_effect_725_f4d_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `sato_2006_effect_725_f4d_red.csv`: the digitized data.
* `sato_2006_effect_725_f4d_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("sato_2006_effect_725_f4d_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{sato_2006_effect_725,
    author = "Sato, Kazuhiro and Yoshimoto, Soichiro and Inukai, Junji and Itaya, Kingo",
    title = "Effect of Sulfuric Acid Concentration on the Structure of Sulfate Adlayer on Au(111) Electrode",
    year = "2006",
    month = "May",
    journal = "Electrochemistry Communications",
    volume = "8",
    number = "5",
    pages = "725--730",
    issn = "1388-2481",
    doi = "10.1016/j.elecom.2006.03.001",
    abstract = "The adsorption of sulfate on Au(111) single-crystal electrode was examined in sulfuric acid solutions of various concentrations (0.5\textendash 7.5 M) by cyclic voltammetry and in situ scanning tunneling microscopy (STM). The well-known sulfate adlayer with ({$\surd$}3 \texttimes{} {$\surd$}7) unit cell was found in 0.5 M sulfuric acid by in situ STM. In 2.5 and 5.0 M sulfuric acid, a new order\textendash disorder phase transition, from the ({$\surd$}3 \texttimes{} {$\surd$}7) adlayer to a disordered structure, was found to take place at ca. 1.1 V vs. Ag{$\mid$}AgCl{$\mid$}KCl(sat.). In 7.5 M sulfuric acid, no current spikes were seen in the CV profile, and in situ STM showed that the sulfate adlayer was disordered.",
    keywords = "Au(111) electrode,Concentration,In situ STM,Phase transition,Sulfate adlayer,sulfuric acid (H2SO4)"
}

```