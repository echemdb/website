# kunze_2003_situ_113_f1b_black

A cyclic voltammogram for
Cu(001)
from Figure 1b in

J. Kunze et al. In situ STM study of the anodic oxidation of Cu(001) in 0.1 M NaOH. Journal of Electroanalytical Chemistry, 554:113–125, 2003

https://doi.org/10.1016/S0022-0728(03)00115-3

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/kunze_2003_situ_113_f1b_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `kunze_2003_situ_113_f1b_black.csv`: the digitized data.
* `kunze_2003_situ_113_f1b_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("kunze_2003_situ_113_f1b_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{kunze_2003_situ_113,
    author = "Kunze, Julia and Maurice, Vincent and Klein, Lorena H and Strehblow, Hans-Henning and Marcus, Philippe",
    title = "In situ STM study of the anodic oxidation of Cu(001) in 0.1 M NaOH",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "554",
    pages = "113--125",
    year = "2003",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(03)00115-3"
}

```