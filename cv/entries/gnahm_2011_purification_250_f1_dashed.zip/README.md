# gnahm_2011_purification_250_f1_dashed

A cyclic voltammogram for
Au(111)
from Figure 1 in

M. Gnahm et al. The purification of an ionic liquid. Journal of electroanalytical chemistry, 651(2):250–252, 2011

https://doi.org/10.1016/j.jelechem.2010.11.019

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/gnahm_2011_purification_250_f1_dashed/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `gnahm_2011_purification_250_f1_dashed.csv`: the digitized data.
* `gnahm_2011_purification_250_f1_dashed.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("gnahm_2011_purification_250_f1_dashed.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{gnahm_2011_purification_250,
    author = "Gnahm, Markus and Kolb, Dieter M",
    title = "The purification of an ionic liquid",
    journal = "Journal of electroanalytical chemistry",
    volume = "651",
    number = "2",
    pages = "250--252",
    year = "2011",
    publisher = "Elsevier",
    doi = "10.1016/j.jelechem.2010.11.019"
}

```