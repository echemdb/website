# wang_1997_lateral_1_f1a_solid

A cyclic voltammogram for
Ag(100)
from Figure 1a in

J. Wang et al. Lateral interaction energy derived from Frumkin isotherm for c(2x2) Br/Ag(100). Technical Report, Brookhaven National Lab., Upton, NY (United States), 1997

https://www.osti.gov/biblio/537264

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wang_1997_lateral_1_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wang_1997_lateral_1_f1a_solid.csv`: the digitized data.
* `wang_1997_lateral_1_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wang_1997_lateral_1_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@techreport{wang_1997_lateral_1,
    author = "Wang, JX and Ocko, BM and Wandlowski, T",
    title = "Lateral interaction energy derived from Frumkin isotherm for c(2x2) Br/Ag(100)",
    year = "1997",
    pages = "1--9",
    institution = "Brookhaven National Lab., Upton, NY (United States)",
    publisher = "No publisher"
}

```