# foelske_2004_initial_10_f2a_solid

A cyclic voltammogram for
Co(0001)
from Figure 2a in

A. Foelske et al. Initial stages of hydroxide formation and its reduction on Co(0001) studied by in situ STM and XPS in 0.1 M NaOH. Surface science, 554(1):10–24, 2004

https://doi.org/10.1016/j.susc.2003.12.059

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/foelske_2004_initial_10_f2a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `foelske_2004_initial_10_f2a_solid.csv`: the digitized data.
* `foelske_2004_initial_10_f2a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("foelske_2004_initial_10_f2a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{foelske_2004_initial_10,
    author = "Foelske, Annette and Kunze, Julia and Strehblow, Hans-Henning",
    title = "Initial stages of hydroxide formation and its reduction on Co(0001) studied by in situ STM and XPS in 0.1 M NaOH",
    journal = "Surface science",
    volume = "554",
    number = "1",
    pages = "10--24",
    year = "2004",
    publisher = "Elsevier",
    doi = "10.1016/j.susc.2003.12.059"
}

```