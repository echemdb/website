# hirai_2000_situ_702_f2_solid

A cyclic voltammogram for
Fe(110)
from Figure 2 in

N. Hirai et al. In situ electrochemical atomic force microscopy with atomic resolution of Fe(110) in sodium sulfate aqueous solution. ISIJ international, 40(7):702–705, 2000

https://doi.org/10.2355/isijinternational.40.702

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/hirai_2000_situ_702_f2_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `hirai_2000_situ_702_f2_solid.csv`: the digitized data.
* `hirai_2000_situ_702_f2_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("hirai_2000_situ_702_f2_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{hirai_2000_situ_702,
    author = "Hirai, Nobumitsu and Okada, Hiromi and Hara, Shigeta",
    title = "In situ electrochemical atomic force microscopy with atomic resolution of Fe(110) in sodium sulfate aqueous solution",
    journal = "ISIJ international",
    volume = "40",
    number = "7",
    pages = "702--705",
    year = "2000",
    publisher = "The Iron and Steel Institute of Japan",
    doi = "10.2355/isijinternational.40.702"
}

```