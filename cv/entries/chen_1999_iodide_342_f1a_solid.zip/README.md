# chen_1999_iodide_342_f1a_solid

A cyclic voltammogram for
Au(111)
from Figure 1a in

A. Chen et al. Iodide Adsorption at the Au(111) Electrode Surface. Journal of Electroanalytical Chemistry, 467(1):342–353, June 1999

https://doi.org/10.1016/S0022-0728(98)00437-9

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/chen_1999_iodide_342_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `chen_1999_iodide_342_f1a_solid.csv`: the digitized data.
* `chen_1999_iodide_342_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("chen_1999_iodide_342_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{chen_1999_iodide_342,
    author = "Chen, Aicheng and Shi, Zhichao and Bizzotto, Dan and Lipkowski, Jacek and Pettinger, Bruno and Bilger, Christoph",
    title = "Iodide Adsorption at the Au(111) Electrode Surface",
    year = "1999",
    month = "June",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "467",
    number = "1",
    pages = "342--353",
    issn = "1572-6657",
    doi = "10.1016/S0022-0728(98)00437-9",
    abstract = "The adsorption of iodide at a Au(111) single crystal electrode has been investigated quantitatively using chronocoulometry. By analyzing the charge density data thermodynamically, the following parameters were determined: the Gibbs excess, Gibbs energy of adsorption, the number of electrons flowing to the interface per one adsorbed iodide ion at a constant electrode potential (electrosorption valency), and at a constant chemical potential. The thermodynamic data for iodide adsorption were compared to the results for bromide and chloride adsorption. All the three halides form a chemisorption bond with the gold surface. The bond is quite polar at the negatively charged surface, however, its polarity drops significantly at the positively charged surface. At low charge densities and coverages, the bond polarity is determined by the ability of free electrons to screen the dipole formed by the adsorbed anion and its image charge in the metal. At high charge densities and coverages, the chemisorption bond has a predominantly covalent character. The strength of the halide adsorption and the covalent character of the chemisorption bond increase progressively by moving from chloride to iodide."
}

```