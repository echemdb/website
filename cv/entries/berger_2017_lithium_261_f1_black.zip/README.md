# berger_2017_lithium_261_f1_black

A cyclic voltammogram for
Au(111)
from Figure 1 in

C. A. Berger et al. Lithium Deposition from a Piperidinium–based Ionic Liquid: Rapping Dendrites on the Knuckles. ChemElectroChem, 4(2):261–265, 2017

https://doi.org/10.1002/celc.201600730

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/berger_2017_lithium_261_f1_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `berger_2017_lithium_261_f1_black.csv`: the digitized data.
* `berger_2017_lithium_261_f1_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("berger_2017_lithium_261_f1_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{berger_2017_lithium_261,
    author = "Berger, Claudia A and Ceblin, Maximilian U and Jacob, Timo",
    title = "Lithium Deposition from a Piperidinium--based Ionic Liquid: Rapping Dendrites on the Knuckles",
    journal = "ChemElectroChem",
    volume = "4",
    number = "2",
    pages = "261--265",
    year = "2017",
    publisher = "Wiley Online Library",
    doi = "10.1002/celc.201600730"
}

```