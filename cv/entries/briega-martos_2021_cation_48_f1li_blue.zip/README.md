# briega-martos_2021_cation_48_f1li_blue

A cyclic voltammogram for
Pt(111)
from Figure 1li in

V. Briega-Martos et al. Cation Effects on Interfacial Water Structure and Hydrogen Peroxide Reduction on Pt (111). ACS Measurement Science Au, 1(2):48–55, 2021

https://doi.org/10.1021/acsmeasuresciau.1c00004

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/briega-martos_2021_cation_48_f1li_blue/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `briega-martos_2021_cation_48_f1li_blue.csv`: the digitized data.
* `briega-martos_2021_cation_48_f1li_blue.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("briega-martos_2021_cation_48_f1li_blue.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{briega-martos_2021_cation_48,
    author = "Briega-Martos, Valentín and Sarabia, Francisco J and Climent, Víctor and Herrero, Enrique and Feliu, Juan M",
    title = "Cation Effects on Interfacial Water Structure and Hydrogen Peroxide Reduction on Pt (111)",
    journal = "ACS Measurement Science Au",
    year = "2021",
    volume = "1",
    number = "2",
    pages = "48--55",
    publisher = "ACS Publications",
    abstract = "The interface between the Pt(111) surface and several MeF/HClO4 (Me+ = Li+, Na+, or Cs+) aqueous electrolytes is investigated by means of cyclic voltammetry and laser-induced temperature jump experiments. Results point out that the effect of the electrolyte on the interfacial water structure is different depending on the nature of the metal alkali cation, with the values of the potential of maximum entropy (pme) following the order pme (Li+) < pme (Na+) < pme (Cs+). In addition, the hydrogen peroxide reduction reaction is studied under these conditions. This reaction is inhibited at low potentials as a consequence of the build up of negative charges on the electrode surface. The potential where this inhibition takes place (Einhibition) follows the same trend as the pme. These results evidence that the activity of an electrocatalytic reaction can depend to great extent on the structure of the interfacial water adlayer and that the latter can be modulated by the nature of the alkali metal cation.",
    doi = "10.1021/acsmeasuresciau.1c00004"
}

```