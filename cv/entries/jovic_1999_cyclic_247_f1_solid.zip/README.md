# jovic_1999_cyclic_247_f1_solid

A cyclic voltammogram for
Ag(111)
from Figure 1 in

B. Jović et al. Cyclic voltammetry on Ag(111) and Ag(100) faces in sodium hydroxide solutions. Electrochemistry communications, 1(6):247–251, 1999

https://doi.org/10.1016/S1388-2481(99)00049-1

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/jovic_1999_cyclic_247_f1_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `jovic_1999_cyclic_247_f1_solid.csv`: the digitized data.
* `jovic_1999_cyclic_247_f1_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("jovic_1999_cyclic_247_f1_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{jovic_1999_cyclic_247,
    author = "Jović, BM and Jović, VD and Stafford, Gery R",
    title = "Cyclic voltammetry on Ag(111) and Ag(100) faces in sodium hydroxide solutions",
    journal = "Electrochemistry communications",
    volume = "1",
    number = "6",
    pages = "247--251",
    year = "1999",
    publisher = "Elsevier",
    doi = "10.1016/S1388-2481(99)00049-1"
}

```