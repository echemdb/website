# blizanac_2004_anion_625_f3a_black

A cyclic voltammogram for
Au(100)
from Figure 3a in

B. B. Blizanac et al. Anion Adsorption, CO Oxidation, and Oxygen Reduction Reaction on a Au(100) Surface:\, The pH Effect. The Journal of Physical Chemistry B, 108(2):625–634, 2004

https://doi.org/10.1021/jp036483l

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/blizanac_2004_anion_625_f3a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `blizanac_2004_anion_625_f3a_black.csv`: the digitized data.
* `blizanac_2004_anion_625_f3a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("blizanac_2004_anion_625_f3a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{blizanac_2004_anion_625,
    author = "Blizanac, B. B. and Lucas, C. A and Gallagher, M. E. and Arenz, M. and Ross, P. N. and Markovi\'c, N. M.",
    title = "Anion Adsorption, CO Oxidation, and Oxygen Reduction Reaction on a Au(100) Surface:\, The pH Effect",
    shorttitle = "Anion Adsorption, CO Oxidation, and Oxygen Reduction Reaction on a Au(100) Surface",
    date = "2004-01-01",
    year = "2004",
    journal = "The Journal of Physical Chemistry B",
    volume = "108",
    number = "2",
    pages = "625--634",
    issn = "1520-6106",
    doi = "10.1021/jp036483l",
    urldate = "2019-03-10",
    abstract = "The effects of pH on the surface reconstruction of Au(100), on CO oxidation, and on the oxygen reduction reaction (ORR) have been studied by a combination of surface X-ray scattering (SXS), Fourier transform infrared (FTIR) spectroscopy, and rotating ring-disk electrode (RRDE) measurements. In harmony with previous SXS and scanning tunneling microscopy (STM) results, the potential-induced hexagonal (``hex'') to (1 \texttimes{} 1) transition occurs faster in an alkaline electrolyte than in acidic media. In alkaline solution, CO adsorption facilitates the formation of a ``hex'' phase; in acid solution, however, CO has negligible effect on the potential range of thermodynamic stability of the ``hex'' {$\leftrightarrow$} (1 \texttimes{} 1) transition. We propose that in KOH the continuous removal of OHad in the Langmuir-Hinshelwood reaction (CO + OH = CO2 + H+ + e-) may stabilize the ``hex'' phase over a much wider potential range than in CO-free solution. In acid solution, where specifically adsorbing anions cannot be displaced by CO from the Au(100) surface, CO has negligible effect on the equilibrium potential for the ``hex'' {$\leftrightarrow$} (1 \texttimes{} 1) transition. Such a mechanism is in agreement with the pH-dependent oxidation of CO. The ORR is also affected by the pH of solution. It is proposed that the pH-dependent kinetics of the ORR on Au(100) can be unraveled by finding the relationship between kinetic rates and two terms:\, (i) the energetic term of the Au(100)-O2- interaction determines the potential regions where the rate-determining step O2 + e = O2- occurs, and (ii) the preexponential term determines the availability of active sites for the adsorption of O2-."
}

```