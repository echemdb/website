# wan_1999_situ_6978_f2_solid

A cyclic voltammogram for
Ir(111)
from Figure 2 in

L.-J. Wan et al. In situ scanning tunneling microscopy of well-defined Ir(111) surface: high-resolution imaging of adsorbed sulfate. The Journal of Physical Chemistry B, 103(33):6978–6983, 1999

https://doi.org/10.1021/jp991112j

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wan_1999_situ_6978_f2_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wan_1999_situ_6978_f2_solid.csv`: the digitized data.
* `wan_1999_situ_6978_f2_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wan_1999_situ_6978_f2_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wan_1999_situ_6978,
    author = "Wan, Li-Jun and Hara, Masanori and Inukai, Jungi and Itaya, Kingo",
    title = "In situ scanning tunneling microscopy of well-defined Ir(111) surface: high-resolution imaging of adsorbed sulfate",
    journal = "The Journal of Physical Chemistry B",
    volume = "103",
    number = "33",
    pages = "6978--6983",
    year = "1999",
    publisher = "ACS Publications",
    doi = "10.1021/jp991112j"
}

```