# feng_2017_new_1003_f9_solid

A cyclic voltammogram for
Pt(POSC)
from Figure 9 in

Z. Feng et al. New advances in ohmic microscopy. Russian Journal of Electrochemistry, 53:1003–1010, 2017

https://doi.org/10.1134/S1023193517090051

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/feng_2017_new_1003_f9_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `feng_2017_new_1003_f9_solid.csv`: the digitized data.
* `feng_2017_new_1003_f9_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("feng_2017_new_1003_f9_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{feng_2017_new_1003,
    author = "Feng, Zhange and Georgescu, Nicholas S and Scherson, Daniel A",
    title = "New advances in ohmic microscopy",
    journal = "Russian Journal of Electrochemistry",
    volume = "53",
    pages = "1003--1010",
    year = "2017",
    publisher = "Springer",
    doi = "10.1134/S1023193517090051"
}

```