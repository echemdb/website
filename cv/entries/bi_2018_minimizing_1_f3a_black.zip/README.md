# bi_2018_minimizing_1_f3a_black

A cyclic voltammogram for
Au(111)
from Figure 3a in

S. Bi et al. Minimizing the electrosorption of water from humid ionic liquids on electrodes. Nature communications, 9(1):1–9, 2018

https://doi.org/10.1038/s41467-018-07674-0

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/bi_2018_minimizing_1_f3a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `bi_2018_minimizing_1_f3a_black.csv`: the digitized data.
* `bi_2018_minimizing_1_f3a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("bi_2018_minimizing_1_f3a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{bi_2018_minimizing_1,
    author = "Bi, Sheng and Wang, Runxi and Liu, Shuai and Yan, Jiawei and Mao, Bingwei and Kornyshev, Alexei A and Feng, Guang",
    title = "Minimizing the electrosorption of water from humid ionic liquids on electrodes",
    journal = "Nature communications",
    volume = "9",
    number = "1",
    pages = "1--9",
    year = "2018",
    publisher = "Nature Publishing Group",
    doi = "10.1038/s41467-018-07674-0"
}

```