# zei_1991_structure_295_f3a_solid

A cyclic voltammogram for
Ag(111)
from Figure 3a in

M. Zei. The structure of halide adlayers on Ag(111) electrodes. Journal of electroanalytical chemistry and interfacial electrochemistry, 308(1-2):295–307, 1991

https://doi.org/10.1016/0022-0728(91)85074-Y

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/zei_1991_structure_295_f3a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `zei_1991_structure_295_f3a_solid.csv`: the digitized data.
* `zei_1991_structure_295_f3a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("zei_1991_structure_295_f3a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{zei_1991_structure_295,
    author = "Zei, MS",
    title = "The structure of halide adlayers on Ag(111) electrodes",
    journal = "Journal of electroanalytical chemistry and interfacial electrochemistry",
    volume = "308",
    number = "1-2",
    pages = "295--307",
    year = "1991",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(91)85074-Y"
}

```