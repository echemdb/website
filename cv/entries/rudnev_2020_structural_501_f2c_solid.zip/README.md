# rudnev_2020_structural_501_f2c_solid

A cyclic voltammogram for
Au(111)
from Figure 2c in

A. V. Rudnev et al. Structural Changes of Au (111) Single-Crystal Electrode Surface in Ionic Liquids. ChemElectroChem, 7(2):501–508, 2020

https://doi.org/10.1002/celc.201902010

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/rudnev_2020_structural_501_f2c_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `rudnev_2020_structural_501_f2c_solid.csv`: the digitized data.
* `rudnev_2020_structural_501_f2c_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("rudnev_2020_structural_501_f2c_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{rudnev_2020_structural_501,
    author = "Rudnev, Alexander V and Ehrenburg, Maria R and Molodkina, Elena B and Abdelrahman, Areeg and Arenz, Matthias and Broekmann, Peter and Jacob, Timo",
    title = "Structural Changes of Au (111) Single-Crystal Electrode Surface in Ionic Liquids",
    journal = "ChemElectroChem",
    volume = "7",
    number = "2",
    pages = "501--508",
    year = "2020",
    publisher = "Wiley Online Library",
    doi = "10.1002/celc.201902010"
}

```