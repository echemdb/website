# atkin_2011_situ_6849_f1_inset

A cyclic voltammogram for
Au(111)
from Figure 1 in

R. Atkin et al. An in situ STM/AFM and impedance spectroscopy study of the extremely pure 1-butyl-1-methylpyrrolidinium tris(pentafluoroethyl)trifluorophosphate/Au(111) interface: potential dependent solvation layers and the herringbone reconstruction. Physical Chemistry Chemical Physics, 13(15):6849–6857, 2011

https://doi.org/10.1039/c0cp02846k

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/atkin_2011_situ_6849_f1_inset/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `atkin_2011_situ_6849_f1_inset.csv`: the digitized data.
* `atkin_2011_situ_6849_f1_inset.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("atkin_2011_situ_6849_f1_inset.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{atkin_2011_situ_6849,
    author = "Atkin, Rob and Borisenko, Natalia and Drüschler, Marcel and El Abedin, Sherif Zein and Endres, Frank and Hayes, Robert and Huber, Benedikt and Roling, Bernhard",
    title = "An in situ STM/AFM and impedance spectroscopy study of the extremely pure 1-butyl-1-methylpyrrolidinium tris(pentafluoroethyl)trifluorophosphate/Au(111) interface: potential dependent solvation layers and the herringbone reconstruction",
    journal = "Physical Chemistry Chemical Physics",
    volume = "13",
    number = "15",
    pages = "6849--6857",
    year = "2011",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/c0cp02846k"
}

```