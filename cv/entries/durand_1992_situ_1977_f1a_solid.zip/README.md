# durand_1992_situ_1977_f1a_solid

A cyclic voltammogram for
Pt(100)
from Figure 1a in

R. Durand et al. In situ X-ray absorption spectroscopy study of underpotential deposition of copper on platinum (100). Electrochimica acta, 37(11):1977–1982, 1992

https://doi.org/10.1016/0013-4686(92)87111-C

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/durand_1992_situ_1977_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `durand_1992_situ_1977_f1a_solid.csv`: the digitized data.
* `durand_1992_situ_1977_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("durand_1992_situ_1977_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{durand_1992_situ_1977,
    author = "Durand, R and Faure, R and Aberdam, D and Salem, C and Tourillon, G and Guay, D and Ladouceur, M",
    title = "In situ X-ray absorption spectroscopy study of underpotential deposition of copper on platinum (100)",
    journal = "Electrochimica acta",
    volume = "37",
    number = "11",
    pages = "1977--1982",
    year = "1992",
    publisher = "Elsevier",
    doi = "10.1016/0013-4686(92)87111-C"
}

```