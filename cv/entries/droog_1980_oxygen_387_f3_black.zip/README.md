# droog_1980_oxygen_387_f3_black

A cyclic voltammogram for
Cu(100)
from Figure 3 in

J. M. Droog et al. Oxygen electrosorption on copper single crystal electrodes in sodium hydroxide solution. Journal of Electroanalytical Chemistry, 112(2):387–390, 1980

https://doi.org/10.1016/S0022-0728(80)80421-9

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/droog_1980_oxygen_387_f3_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `droog_1980_oxygen_387_f3_black.csv`: the digitized data.
* `droog_1980_oxygen_387_f3_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("droog_1980_oxygen_387_f3_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{droog_1980_oxygen_387,
    author = "Droog, John MM and Schlenter, Bernadette",
    title = "Oxygen electrosorption on copper single crystal electrodes in sodium hydroxide solution",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "112",
    number = "2",
    pages = "387--390",
    year = "1980",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(80)80421-9"
}

```