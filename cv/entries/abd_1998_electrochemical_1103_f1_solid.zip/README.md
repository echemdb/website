# abd_1998_electrochemical_1103_f1_solid

A cyclic voltammogram for
Ag(poly)
from Figure 1 in

S. S. Abd El Rehim et al. Electrochemical behaviour of a silver electrode in NaOH solutions. Monatshefte für Chemie/Chemical Monthly, 129(11):1103–1117, 1998

https://doi.org/10.1007/PL00010123

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/abd_1998_electrochemical_1103_f1_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `abd_1998_electrochemical_1103_f1_solid.csv`: the digitized data.
* `abd_1998_electrochemical_1103_f1_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("abd_1998_electrochemical_1103_f1_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{abd_1998_electrochemical_1103,
    author = "Abd El Rehim, Sayed S and Hassan, Hamdy H and Ibrahim, Magdy AM and Amin, Mohammed A",
    title = "Electrochemical behaviour of a silver electrode in NaOH solutions",
    journal = "Monatshefte für Chemie/Chemical Monthly",
    volume = "129",
    number = "11",
    pages = "1103--1117",
    year = "1998",
    publisher = "Springer",
    doi = "10.1007/PL00010123"
}

```