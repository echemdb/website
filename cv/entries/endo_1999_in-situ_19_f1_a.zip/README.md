# endo_1999_in-situ_19_f1_a

A cyclic voltammogram for
Ag(100)
from Figure 1 in

O. Endo et al. In-situ X-ray absorption studies of bromine on the Ag(100) electrode. Journal of Electroanalytical Chemistry, 473(1-2):19–24, 1999

https://doi.org/10.1016/S0022-0728(99)00148-5

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/endo_1999_in-situ_19_f1_a/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `endo_1999_in-situ_19_f1_a.csv`: the digitized data.
* `endo_1999_in-situ_19_f1_a.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("endo_1999_in-situ_19_f1_a.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{endo_1999_in-situ_19,
    author = "Endo, Osamu and Kiguchi, Manabu and Yokoyama, Toshihiko and Ito, Masatoki and Ohta, Toshiaki",
    title = "In-situ X-ray absorption studies of bromine on the Ag(100) electrode",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "473",
    number = "1-2",
    pages = "19--24",
    year = "1999",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(99)00148-5"
}

```