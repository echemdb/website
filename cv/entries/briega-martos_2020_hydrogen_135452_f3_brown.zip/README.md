# briega-martos_2020_hydrogen_135452_f3_brown

A cyclic voltammogram for
Pt(553)
from Figure 3 in

V. Briega-Martos et al. Hydrogen peroxide and oxygen reduction studies on Pt stepped surfaces: surface charge effects and mechanistic consequences. Electrochimica Acta, 334:135452, 2020

https://doi.org/10.1016/j.electacta.2019.135452

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/briega-martos_2020_hydrogen_135452_f3_brown/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `briega-martos_2020_hydrogen_135452_f3_brown.csv`: the digitized data.
* `briega-martos_2020_hydrogen_135452_f3_brown.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("briega-martos_2020_hydrogen_135452_f3_brown.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{briega-martos_2020_hydrogen_135452,
    author = "Briega-Martos, Valentín and Herrero, Enrique and Feliu, Juan M",
    title = "Hydrogen peroxide and oxygen reduction studies on Pt stepped surfaces: surface charge effects and mechanistic consequences",
    journal = "Electrochimica Acta",
    volume = "334",
    pages = "135452",
    year = "2020",
    publisher = "Elsevier",
    doi = "10.1016/j.electacta.2019.135452"
}

```