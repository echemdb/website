# kibler_2000_in-situ_73_f8a_black

A cyclic voltammogram for
Pt(100)
from Figure 8a in

L. A. Kibler et al. In-Situ STM Characterisation of the Surface Morphology of Platinum Single Crystal Electrodes as a Function of Their Preparation. Journal of Electroanalytical Chemistry, 484(1):73–82, 2000

https://doi.org/10.1016/S0022-0728(00)00065-6

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/kibler_2000_in-situ_73_f8a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `kibler_2000_in-situ_73_f8a_black.csv`: the digitized data.
* `kibler_2000_in-situ_73_f8a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("kibler_2000_in-situ_73_f8a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{kibler_2000_in-situ_73,
    author = "Kibler, L. A and Cuesta, A and Kleinert, M and Kolb, D. M",
    title = "In-Situ STM Characterisation of the Surface Morphology of Platinum Single Crystal Electrodes as a Function of Their Preparation",
    date = "2000-04-07",
    year = "2000",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "484",
    number = "1",
    pages = "73--82",
    issn = "1572-6657",
    doi = "10.1016/S0022-0728(00)00065-6",
    urldate = "2019-03-02",
    abstract = "A systematic study of the surface morphology of Pt(111) and Pt(100) electrodes as prepared by flame-annealing and cooling in different atmospheres (air, N2, H2+N2 and CO+N2) is presented. The electrodes were characterised by cyclic voltammetry and in-situ STM in 0.1 M H2SO4. Preliminary voltammetric results for Pt(110) are also shown. In this case, Cu upd served as a structure sensitive probe. It was observed that the presence of oxygen during cooling induces surface defects and leads to rough surfaces. Cooling in pure N2 preserves the reconstructed Pt(100) and Pt(110) surfaces, while cooling in H2+N2 or CO+N2 lifts the reconstruction. The use of CO as the cooling gas turned out to be advantageous for the preparation of clean and well-ordered (1×1)-surfaces. The stability of reconstructed Pt surfaces in an electrochemical environment is discussed. For H2+N2-cooled Pt electrodes, a clear influence of the H2-concentration on the surface morphology was observed.",
    keywords = "Platinum single crystal electrodes,STM,Surface morphology"
}

```