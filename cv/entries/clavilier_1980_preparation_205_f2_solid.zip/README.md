# clavilier_1980_preparation_205_f2_solid

A cyclic voltammogram for
Pt(110)
from Figure 2 in

J. Clavilier et al. Preparation of monocrystalline Pt microelectrodes and electrochemical study of the plane surfaces cut in the direction of the $\$111$\$ and $\$110$\$ planes. Journal of Electroanalytical Chemistry and Interfacial Electrochemistry, 107(1):205–209, 1980

https://doi.org/10.1016/S0022-0728(79)80022-4

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/clavilier_1980_preparation_205_f2_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `clavilier_1980_preparation_205_f2_solid.csv`: the digitized data.
* `clavilier_1980_preparation_205_f2_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("clavilier_1980_preparation_205_f2_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{clavilier_1980_preparation_205,
    author = "Clavilier, J and Faure, R and Guinet, G and Durand, R",
    title = "Preparation of monocrystalline Pt microelectrodes and electrochemical study of the plane surfaces cut in the direction of the $\{$111$\}$ and $\{$110$\}$ planes",
    journal = "Journal of Electroanalytical Chemistry and Interfacial Electrochemistry",
    volume = "107",
    number = "1",
    pages = "205--209",
    year = "1980",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(79)80022-4"
}

```