# borisenko_2006_situ_6250_f1_a

A cyclic voltammogram for
Au(111)
from Figure 1 in

N. Borisenko et al. In situ STM investigation of gold reconstruction and of silicon electrodeposition on Au(111) in the room temperature ionic liquid 1-butyl-1-methylpyrrolidinium bis(trifluoromethylsulfonyl)imide. The journal of physical chemistry B, 110(12):6250–6256, 2006

https://doi.org/10.1021/jp057337d

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/borisenko_2006_situ_6250_f1_a/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `borisenko_2006_situ_6250_f1_a.csv`: the digitized data.
* `borisenko_2006_situ_6250_f1_a.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("borisenko_2006_situ_6250_f1_a.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{borisenko_2006_situ_6250,
    author = "Borisenko, N and Zein El Abedin, Sh and Endres, F",
    title = "In situ STM investigation of gold reconstruction and of silicon electrodeposition on Au(111) in the room temperature ionic liquid 1-butyl-1-methylpyrrolidinium bis(trifluoromethylsulfonyl)imide",
    journal = "The journal of physical chemistry B",
    volume = "110",
    number = "12",
    pages = "6250--6256",
    year = "2006",
    publisher = "ACS Publications",
    doi = "10.1021/jp057337d"
}

```