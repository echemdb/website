# li_2000_chronocoulometric_95_f1_dotted

A cyclic voltammogram for
Pt(111)
from Figure 1 in

N. Li et al. Chronocoulometric studies of chloride adsorption at the Pt(111) electrode surface. Journal of Electroanalytical Chemistry, 491(1-2):95–102, 2000

https://doi.org/10.1016/S0022-0728(00)00199-6

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/li_2000_chronocoulometric_95_f1_dotted/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `li_2000_chronocoulometric_95_f1_dotted.csv`: the digitized data.
* `li_2000_chronocoulometric_95_f1_dotted.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("li_2000_chronocoulometric_95_f1_dotted.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{li_2000_chronocoulometric_95,
    author = "Li, Nanhai and Lipkowski, Jacek",
    title = "Chronocoulometric studies of chloride adsorption at the Pt(111) electrode surface",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "491",
    number = "1-2",
    pages = "95--102",
    year = "2000",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(00)00199-6"
}

```