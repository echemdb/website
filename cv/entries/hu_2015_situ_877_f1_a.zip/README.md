# hu_2015_situ_877_f1_a

A cyclic voltammogram for
Au(111)
from Figure 1 in

X. Hu et al. An in situ STM investigation of EMITFSI ionic liquid on Au(111) in the presence of lithium salt. Science Bulletin, 60(9):877–883, 2015

https://doi.org/10.1007/s11434-015-0746-7

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/hu_2015_situ_877_f1_a/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `hu_2015_situ_877_f1_a.csv`: the digitized data.
* `hu_2015_situ_877_f1_a.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("hu_2015_situ_877_f1_a.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{hu_2015_situ_877,
    author = "Hu, Xiaoyan and Chen, Chunlei and Tang, Shuai and Wang, Weiwei and Yan, Jiawei and Mao, Bingwei",
    title = "An in situ STM investigation of EMITFSI ionic liquid on Au(111) in the presence of lithium salt",
    journal = "Science Bulletin",
    volume = "60",
    number = "9",
    pages = "877--883",
    year = "2015",
    publisher = "Springer",
    doi = "10.1007/s11434-015-0746-7"
}

```