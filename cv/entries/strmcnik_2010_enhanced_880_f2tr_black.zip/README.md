# strmcnik_2010_enhanced_880_f2tr_black

A cyclic voltammogram for
Pt(111)
from Figure 2tr in

D. Strmcnik et al. Enhanced electrocatalysis of the oxygen reduction reaction based on patterning of platinum surfaces with cyanide. Nature chemistry, 2(10):880–885, 2010

https://doi.org/10.1038/nchem.771

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/strmcnik_2010_enhanced_880_f2tr_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `strmcnik_2010_enhanced_880_f2tr_black.csv`: the digitized data.
* `strmcnik_2010_enhanced_880_f2tr_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("strmcnik_2010_enhanced_880_f2tr_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{strmcnik_2010_enhanced_880,
    author = "Strmcnik, Dusan and Escudero-Escribano, María and Kodama, Kensaku and Stamenkovic, Vojislav R and Cuesta, Angel and Marković, Nenad M",
    title = "Enhanced electrocatalysis of the oxygen reduction reaction based on patterning of platinum surfaces with cyanide",
    journal = "Nature chemistry",
    volume = "2",
    number = "10",
    pages = "880--885",
    year = "2010",
    publisher = "Nature Publishing Group UK London",
    doi = "10.1038/nchem.771"
}

```