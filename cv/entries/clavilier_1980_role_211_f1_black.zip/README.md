# clavilier_1980_role_211_f1_black

A cyclic voltammogram for
Pt(111)
from Figure 1 in

J. Clavilier. The role of anion on the electrochemical behaviour of a $\$111$\$ platinum surface; an unusual splitting of the voltammogram in the hydrogen region. Journal of Electroanalytical Chemistry and Interfacial Electrochemistry, 107(1):211–216, 1980

https://doi.org/10.1016/S0022-0728(79)80023-6

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/clavilier_1980_role_211_f1_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `clavilier_1980_role_211_f1_black.csv`: the digitized data.
* `clavilier_1980_role_211_f1_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("clavilier_1980_role_211_f1_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{clavilier_1980_role_211,
    author = "Clavilier, J",
    title = "The role of anion on the electrochemical behaviour of a $\{$111$\}$ platinum surface; an unusual splitting of the voltammogram in the hydrogen region",
    journal = "Journal of Electroanalytical Chemistry and Interfacial Electrochemistry",
    volume = "107",
    number = "1",
    pages = "211--216",
    year = "1980",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(79)80023-6"
}

```