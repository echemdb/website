# hara_2007_preparation_5733_f2c_solid

A cyclic voltammogram for
Pd(110)
from Figure 2c in

M. Hara et al. Preparation and electrochemical characterization of palladium single crystal electrodes in 0.1 M H2SO4 and HClO4: Part I. Low-index phases. Electrochimica Acta, 52(18):5733–5748, 2007

https://doi.org/10.1016/j.electacta.2006.11.048

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/hara_2007_preparation_5733_f2c_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `hara_2007_preparation_5733_f2c_solid.csv`: the digitized data.
* `hara_2007_preparation_5733_f2c_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("hara_2007_preparation_5733_f2c_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{hara_2007_preparation_5733,
    author = "Hara, M and Linke, U and Wandlowski, Th",
    title = "Preparation and electrochemical characterization of palladium single crystal electrodes in 0.1 M H2SO4 and HClO4: Part I. Low-index phases",
    journal = "Electrochimica Acta",
    volume = "52",
    number = "18",
    pages = "5733--5748",
    year = "2007",
    publisher = "Elsevier",
    doi = "10.1016/j.electacta.2006.11.048"
}

```