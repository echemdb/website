# borisenko_2012_situ_1736_f1_green

A cyclic voltammogram for
Au(111)
from Figure 1 in

N. Borisenko et al. An in situ STM and DTS study of the extremely pure [EMIM]FAP/Au(111) Interface. ChemPhysChem, 13(7):1736–1742, 2012

https://doi.org/10.1002/cphc.201100873

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/borisenko_2012_situ_1736_f1_green/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `borisenko_2012_situ_1736_f1_green.csv`: the digitized data.
* `borisenko_2012_situ_1736_f1_green.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("borisenko_2012_situ_1736_f1_green.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{borisenko_2012_situ_1736,
    author = "Borisenko, Natalia and Zein El Abedin, Sherif and Endres, Frank",
    title = "An in situ STM and DTS study of the extremely pure [EMIM]FAP/Au(111) Interface",
    journal = "ChemPhysChem",
    volume = "13",
    number = "7",
    pages = "1736--1742",
    year = "2012",
    publisher = "Wiley Online Library",
    doi = "10.1002/cphc.201100873"
}

```