# abe_2019_electro-oxidation_315_f4a1_black

A cyclic voltammogram for
Pt(100)
from Figure 4a1 in

K. Abe et al. Electro-oxidation of CO saturated in 0.1 M HClO4 on basal and stepped Pt single-crystal electrodes at room temperature accompanied by surface reconstruction. Surfaces, 2(2):315–325, 2019

https://doi.org/10.3390/surfaces2020023

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/abe_2019_electro-oxidation_315_f4a1_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `abe_2019_electro-oxidation_315_f4a1_black.csv`: the digitized data.
* `abe_2019_electro-oxidation_315_f4a1_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("abe_2019_electro-oxidation_315_f4a1_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{abe_2019_electro-oxidation_315,
    author = "Abe, Kiyotaka and Uchida, Hiroyuki and Inukai, Junji",
    title = "Electro-oxidation of CO saturated in 0.1 M HClO4 on basal and stepped Pt single-crystal electrodes at room temperature accompanied by surface reconstruction",
    journal = "Surfaces",
    volume = "2",
    number = "2",
    pages = "315--325",
    year = "2019",
    publisher = "MDPI",
    doi = "10.3390/surfaces2020023"
}

```