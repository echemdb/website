# jerkiewicz_2009_effect_12309_f1_solid

A cyclic voltammogram for
Pt(111)
from Figure 1 in

G. Jerkiewicz et al. Effect of temperature variation on the under-potential deposition of copper on Pt(111) in aqueous H2SO4. The Journal of Physical Chemistry C, 113(28):12309–12316, 2009

https://doi.org/10.1021/jp900478u

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/jerkiewicz_2009_effect_12309_f1_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `jerkiewicz_2009_effect_12309_f1_solid.csv`: the digitized data.
* `jerkiewicz_2009_effect_12309_f1_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("jerkiewicz_2009_effect_12309_f1_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{jerkiewicz_2009_effect_12309,
    author = "Jerkiewicz, Gregory and Perreault, Frederic and Radovic-Hrapovic, Zorana",
    title = "Effect of temperature variation on the under-potential deposition of copper on Pt(111) in aqueous H2SO4",
    journal = "The Journal of Physical Chemistry C",
    volume = "113",
    number = "28",
    pages = "12309--12316",
    year = "2009",
    publisher = "ACS Publications",
    doi = "10.1021/jp900478u"
}

```