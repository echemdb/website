# markovic_1996_oxygen_6715_f1_111

A cyclic voltammogram for
Pt(111)
from Figure 1 in

N. M. Markovic et al. Oxygen reduction on platinum low-index single-crystal surfaces in alkaline solution: rotating ring disk Pt(hkl) studies. The Journal of Physical Chemistry, 100(16):6715–6721, 1996

https://doi.org/10.1021/jp9533382

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/markovic_1996_oxygen_6715_f1_111/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `markovic_1996_oxygen_6715_f1_111.csv`: the digitized data.
* `markovic_1996_oxygen_6715_f1_111.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("markovic_1996_oxygen_6715_f1_111.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{markovic_1996_oxygen_6715,
    author = "Markovic, Nenad M and Gasteiger, Hubert A and Ross, Philip N",
    title = "Oxygen reduction on platinum low-index single-crystal surfaces in alkaline solution: rotating ring disk Pt(hkl) studies",
    journal = "The Journal of Physical Chemistry",
    volume = "100",
    number = "16",
    pages = "6715--6721",
    year = "1996",
    publisher = "ACS Publications",
    doi = "10.1021/jp9533382"
}

```