# wandlowski_1996_structural_10277_f1a_dashed

A cyclic voltammogram for
Au(100)
from Figure 1a in

T. Wandlowski et al. Structural and kinetic aspects of bromide adsorption on Au(100). The Journal of Physical Chemistry, 100(24):10277–10287, 1996

https://doi.org/10.1021/jp9600064

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wandlowski_1996_structural_10277_f1a_dashed/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wandlowski_1996_structural_10277_f1a_dashed.csv`: the digitized data.
* `wandlowski_1996_structural_10277_f1a_dashed.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wandlowski_1996_structural_10277_f1a_dashed.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wandlowski_1996_structural_10277,
    author = "Wandlowski, Th and Wang, JX and Magnussen, OM and Ocko, BM",
    title = "Structural and kinetic aspects of bromide adsorption on Au(100)",
    journal = "The Journal of Physical Chemistry",
    volume = "100",
    number = "24",
    pages = "10277--10287",
    year = "1996",
    publisher = "ACS Publications",
    doi = "10.1021/jp9600064"
}

```