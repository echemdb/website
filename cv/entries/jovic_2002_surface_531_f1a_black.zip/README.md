# jovic_2002_surface_531_f1a_black

A cyclic voltammogram for
Cu(111)
from Figure 1a in

V. Jović et al. Surface reconstruction during the adsorption/desorption of OH species onto Cu(111) and Cu(100) in 0.1 M NaOH solution. Journal of the Serbian Chemical Society, 67(7):531–546, 2002

http://dx.doi.org/10.2298/JSC0207531J

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/jovic_2002_surface_531_f1a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `jovic_2002_surface_531_f1a_black.csv`: the digitized data.
* `jovic_2002_surface_531_f1a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("jovic_2002_surface_531_f1a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{jovic_2002_surface_531,
    author = "Jović, Vladimir and Jović, Borka",
    title = "Surface reconstruction during the adsorption/desorption of OH species onto Cu(111) and Cu(100) in 0.1 M NaOH solution",
    journal = "Journal of the Serbian Chemical Society",
    volume = "67",
    number = "7",
    pages = "531--546",
    year = "2002",
    publisher = "Belgrade: Serbian Chemical Society",
    doi = "10.2298/JSC0207531J"
}

```