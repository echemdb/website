# lipkowski_1998_ionic_2875_f1a_i

A cyclic voltammogram for
Au(111)
from Figure 1a in

J. Lipkowski et al. Ionic adsorption at the Au(111) electrode. Electrochimica acta, 43(19-20):2875–2888, 1998

https://doi.org/10.1016/S0013-4686(98)00028-0

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/lipkowski_1998_ionic_2875_f1a_i/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `lipkowski_1998_ionic_2875_f1a_i.csv`: the digitized data.
* `lipkowski_1998_ionic_2875_f1a_i.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("lipkowski_1998_ionic_2875_f1a_i.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{lipkowski_1998_ionic_2875,
    author = "Lipkowski, Jacek and Shi, Zhichao and Chen, Aicheng and Pettinger, Bruno and Bilger, Christoph",
    title = "Ionic adsorption at the Au(111) electrode",
    journal = "Electrochimica acta",
    volume = "43",
    number = "19-20",
    pages = "2875--2888",
    year = "1998",
    publisher = "Elsevier",
    doi = "10.1016/S0013-4686(98)00028-0"
}

```