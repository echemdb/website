# clavilier_1990_situ_1_f5_554

A cyclic voltammogram for
Pt(554)
from Figure 5 in

J. Clavilier et al. In situ probing of step and terrace sites on Pt (S)-[n (111)×(111)] electrodes. Chemical physics, 141(1):1–14, 1990

https://doi.org/10.1016/0301-0104(90)80014-O

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/clavilier_1990_situ_1_f5_554/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `clavilier_1990_situ_1_f5_554.csv`: the digitized data.
* `clavilier_1990_situ_1_f5_554.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("clavilier_1990_situ_1_f5_554.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{clavilier_1990_situ_1,
    author = "Clavilier, Jean and El Achi, Kamal and Rodes, Antonio",
    title = "In situ probing of step and terrace sites on Pt (S)-[n (111)$\times$(111)] electrodes",
    journal = "Chemical physics",
    volume = "141",
    number = "1",
    pages = "1--14",
    year = "1990",
    publisher = "Elsevier",
    doi = "10.1016/0301-0104(90)80014-O"
}

```