# ganassin_2015_non-covalent_8349_f2a_red

A cyclic voltammogram for
Pt(111)
from Figure 2a in

A. Ganassin et al. Non-covalent interactions in water electrolysis: influence on the activity of Pt(111) and iridium oxide catalysts in acidic media. Physical Chemistry Chemical Physics, 17(13):8349–8355, 2015

https://doi.org/10.1039/C4CP04791E

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/ganassin_2015_non-covalent_8349_f2a_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `ganassin_2015_non-covalent_8349_f2a_red.csv`: the digitized data.
* `ganassin_2015_non-covalent_8349_f2a_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("ganassin_2015_non-covalent_8349_f2a_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{ganassin_2015_non-covalent_8349,
    author = "Ganassin, Alberto and Colic, Viktor and Tymoczko, Jakub and Bandarenka, Aliaksandr S and Schuhmann, Wolfgang",
    title = "Non-covalent interactions in water electrolysis: influence on the activity of Pt(111) and iridium oxide catalysts in acidic media",
    journal = "Physical Chemistry Chemical Physics",
    volume = "17",
    number = "13",
    pages = "8349--8355",
    year = "2015",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/C4CP04791E"
}

```