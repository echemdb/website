# arulmozhi_2018_design_113_f8_spherical

A cyclic voltammogram for
Pt(poly)
from Figure 8 in

N. Arulmozhi et al. Design and development of instrumentations for the preparation of platinum single crystals for electrochemistry and electrocatalysis research part 3: final treatment, electrochemical measurements, and recommended laboratory practices. Electrocatalysis, 9:113–123, 2018

https://doi.org/10.1007/s12678-017-0426-2

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/arulmozhi_2018_design_113_f8_spherical/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `arulmozhi_2018_design_113_f8_spherical.csv`: the digitized data.
* `arulmozhi_2018_design_113_f8_spherical.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("arulmozhi_2018_design_113_f8_spherical.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{arulmozhi_2018_design_113,
    author = "Arulmozhi, Nakkiran and Esau, Derek and van Drunen, Julia and Jerkiewicz, Gregory",
    title = "Design and development of instrumentations for the preparation of platinum single crystals for electrochemistry and electrocatalysis research part 3: final treatment, electrochemical measurements, and recommended laboratory practices",
    journal = "Electrocatalysis",
    volume = "9",
    pages = "113--123",
    year = "2018",
    publisher = "Springer",
    doi = "10.1007/s12678-017-0426-2"
}

```