# wallauer_2013_differential_1143_f3d_bottom

A cyclic voltammogram for
Au(111)
from Figure 3d in

J. Wallauer et al. The differential capacitance of ionic liquid/metal electrode interfaces–A critical comparison of experimental results with theoretical predictions. Zeitschrift für Naturforschung B, 68(10):1143–1153, 2013

https://doi.org/10.5560/ZNB.2013-3153

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wallauer_2013_differential_1143_f3d_bottom/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wallauer_2013_differential_1143_f3d_bottom.csv`: the digitized data.
* `wallauer_2013_differential_1143_f3d_bottom.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wallauer_2013_differential_1143_f3d_bottom.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wallauer_2013_differential_1143,
    author = "Wallauer, Jens and Drüschler, Marcel and Huber, Benedikt and Roling, Bernhard",
    title = "The differential capacitance of ionic liquid/metal electrode interfaces--A critical comparison of experimental results with theoretical predictions",
    journal = "Zeitschrift für Naturforschung B",
    volume = "68",
    number = "10",
    pages = "1143--1153",
    year = "2013",
    publisher = "Verlag der Zeitschrift für Naturforschung",
    doi = "10.5560/ZNB.2013-3153"
}

```