# gomez_1993_electrochemical_189_f1_solid

A cyclic voltammogram for
Pt(110)
from Figure 1 in

R. Gómez et al. Electrochemical behaviour of platinum surfaces containing (110) sites and the problem of the third oxidation peak. Journal of Electroanalytical Chemistry, 354(1-2):189–208, 1993

https://doi.org/10.1016/0022-0728(93)80333-D

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/gomez_1993_electrochemical_189_f1_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `gomez_1993_electrochemical_189_f1_solid.csv`: the digitized data.
* `gomez_1993_electrochemical_189_f1_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("gomez_1993_electrochemical_189_f1_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{gomez_1993_electrochemical_189,
    author = "Gómez, R and Clavilier, J",
    title = "Electrochemical behaviour of platinum surfaces containing (110) sites and the problem of the third oxidation peak",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "354",
    number = "1-2",
    pages = "189--208",
    year = "1993",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(93)80333-D"
}

```