# domke_2003_determination_115_f2_dash-dot

A cyclic voltammogram for
Pt(711)
from Figure 2 in

K. Domke et al. Determination of the potentials of zero total charge of Pt(100) stepped surfaces in the [011] zone. Effect of the step density and anion adsorption. Journal of Electroanalytical Chemistry, 552:115–128, 2003

https://doi.org/10.1016/S0022-0728(02)01471-7

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/domke_2003_determination_115_f2_dash-dot/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `domke_2003_determination_115_f2_dash-dot.csv`: the digitized data.
* `domke_2003_determination_115_f2_dash-dot.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("domke_2003_determination_115_f2_dash-dot.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{domke_2003_determination_115,
    author = "Domke, Katrin and Herrero, Enrique and Rodes, Antonio and Feliu, Juan M",
    title = "Determination of the potentials of zero total charge of Pt(100) stepped surfaces in the [011] zone. Effect of the step density and anion adsorption",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "552",
    pages = "115--128",
    year = "2003",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(02)01471-7"
}

```