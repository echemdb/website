# gomez-marin_2012_pt-111_558_f2_pink

A cyclic voltammogram for
Pt(111)
from Figure 2 in

A. M. Gómez-Marín et al. Pt(111) surface disorder kinetics in perchloric acid solutions and the influence of specific anion adsorption. Electrochimica acta, 82:558–569, 2012

https://doi.org/10.1016/j.electacta.2012.04.066

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/gomez-marin_2012_pt-111_558_f2_pink/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `gomez-marin_2012_pt-111_558_f2_pink.csv`: the digitized data.
* `gomez-marin_2012_pt-111_558_f2_pink.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("gomez-marin_2012_pt-111_558_f2_pink.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{gomez-marin_2012_pt-111_558,
    author = "Gómez-Marín, Ana Ma and Feliu, Juan M",
    title = "Pt(111) surface disorder kinetics in perchloric acid solutions and the influence of specific anion adsorption",
    journal = "Electrochimica acta",
    volume = "82",
    pages = "558--569",
    year = "2012",
    publisher = "Elsevier",
    doi = "10.1016/j.electacta.2012.04.066"
}

```