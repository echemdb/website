# shi_1996_chloride_225_f1_dotted

A cyclic voltammogram for
Au(111)
from Figure 1 in

Z. Shi et al. Chloride adsorption at the Au(111) electrode surface. Journal of Electroanalytical Chemistry, 403(1-2):225–239, 1996

https://doi.org/10.1016/0022-0728(92)80223-Q

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/shi_1996_chloride_225_f1_dotted/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `shi_1996_chloride_225_f1_dotted.csv`: the digitized data.
* `shi_1996_chloride_225_f1_dotted.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("shi_1996_chloride_225_f1_dotted.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{shi_1996_chloride_225,
    author = "Shi, Zhichao and Lipkowski, Jacek",
    title = "Chloride adsorption at the Au(111) electrode surface",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "403",
    number = "1-2",
    pages = "225--239",
    year = "1996",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(92)80223-Q"
}

```