# pajkossy_1996_impedance_209_f8a_a

A cyclic voltammogram for
Au(100)
from Figure 8a in

T. Pajkossy et al. Impedance aspects of anion adsorption on gold single crystal electrodes. Journal of Electroanalytical Chemistry, 414(2):209–220, 1996

https://doi.org/10.1016/0022-0728(96)04700-6

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/pajkossy_1996_impedance_209_f8a_a/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `pajkossy_1996_impedance_209_f8a_a.csv`: the digitized data.
* `pajkossy_1996_impedance_209_f8a_a.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("pajkossy_1996_impedance_209_f8a_a.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{pajkossy_1996_impedance_209,
    author = "Pajkossy, Tamàs and Wandlowski, Thomas and Kolb, Dieter M",
    title = "Impedance aspects of anion adsorption on gold single crystal electrodes",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "414",
    number = "2",
    pages = "209--220",
    year = "1996",
    publisher = "Elsevier",
    doi = "10.1016/0022-0728(96)04700-6"
}

```