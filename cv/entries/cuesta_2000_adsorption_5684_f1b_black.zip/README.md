# cuesta_2000_adsorption_5684_f1b_black

A cyclic voltammogram for
Au(111)
from Figure 1b in

A. Cuesta et al. The adsorption of sulfate and phosphate on Au(111) and Au(100) electrodes: an in situ STM study. Physical Chemistry Chemical Physics, 2(24):5684–5690, 2000

https://doi.org/10.1039/B006464P

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/cuesta_2000_adsorption_5684_f1b_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `cuesta_2000_adsorption_5684_f1b_black.csv`: the digitized data.
* `cuesta_2000_adsorption_5684_f1b_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("cuesta_2000_adsorption_5684_f1b_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{cuesta_2000_adsorption_5684,
    author = "Cuesta, Angel and Kleinert, Markus and Kolb, Dieter M.",
    title = "The adsorption of sulfate and phosphate on Au(111) and Au(100) electrodes: an in situ STM study",
    volume = "2",
    ISSN = "1463-9084",
    doi = "10.1039/B006464P",
    number = "24",
    journal = "Physical Chemistry Chemical Physics",
    publisher = "Royal Society of Chemistry (RSC)",
    year = "2000",
    pages = "5684--5690"
}

```