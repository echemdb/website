# motobayashi_2016_potential-dependent_14_f2b_red

A cyclic voltammogram for
Au(poly)
from Figure 2b in

K. Motobayashi et al. Potential-dependent condensation of Water at the Interface between ionic liquid [BMIM][TFSA] and an Au electrode. Electrochemistry Communications, 65:14–17, 2016

https://doi.org/10.1016/j.elecom.2016.01.018

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/motobayashi_2016_potential-dependent_14_f2b_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `motobayashi_2016_potential-dependent_14_f2b_red.csv`: the digitized data.
* `motobayashi_2016_potential-dependent_14_f2b_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("motobayashi_2016_potential-dependent_14_f2b_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{motobayashi_2016_potential-dependent_14,
    author = "Motobayashi, Kenta and Osawa, Masatoshi",
    title = "Potential-dependent condensation of Water at the Interface between ionic liquid [BMIM][TFSA] and an Au electrode",
    journal = "Electrochemistry Communications",
    volume = "65",
    pages = "14--17",
    year = "2016",
    publisher = "Elsevier",
    doi = "10.1016/j.elecom.2016.01.018"
}

```