# beden_1985_voltammetric_822_f2b_solid

A cyclic voltammogram for
Ni(110)
from Figure 2b in

B. Beden et al. A voltammetric study of the formation on hydroxides and oxyhydroxides on nickel single crystal electrodes in contact with an alkaline solution. Surface Science, 162(1-3):822–829, 1985

https://doi.org/10.1016/0039-6028(85)90985-9

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/beden_1985_voltammetric_822_f2b_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `beden_1985_voltammetric_822_f2b_solid.csv`: the digitized data.
* `beden_1985_voltammetric_822_f2b_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("beden_1985_voltammetric_822_f2b_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{beden_1985_voltammetric_822,
    author = "Beden, B and Floner, DJML and Leger, JM and Lamy, C",
    title = "A voltammetric study of the formation on hydroxides and oxyhydroxides on nickel single crystal electrodes in contact with an alkaline solution",
    journal = "Surface Science",
    volume = "162",
    number = "1-3",
    pages = "822--829",
    year = "1985",
    publisher = "Elsevier",
    doi = "10.1016/0039-6028(85)90985-9"
}

```