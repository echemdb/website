# alves_2011_electrochemistry_6010_f2_red

A cyclic voltammogram for
Ru(0001)
from Figure 2 in

O. B. Alves et al. Electrochemistry at Ru(0001) in a flowing CO-saturated electrolyte–reactive and inert adlayer phases. Physical Chemistry Chemical Physics, 13(13):6010–6021, 2011

https://doi.org/10.1039/C0CP01001D

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/alves_2011_electrochemistry_6010_f2_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `alves_2011_electrochemistry_6010_f2_red.csv`: the digitized data.
* `alves_2011_electrochemistry_6010_f2_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("alves_2011_electrochemistry_6010_f2_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{alves_2011_electrochemistry_6010,
    author = "Alves, Otavio B and Hoster, Harry E and Behm, Rolf Jürgen",
    title = "Electrochemistry at Ru(0001) in a flowing CO-saturated electrolyte--reactive and inert adlayer phases",
    journal = "Physical Chemistry Chemical Physics",
    volume = "13",
    number = "13",
    pages = "6010--6021",
    year = "2011",
    publisher = "Royal Society of Chemistry",
    abstract = "We investigated the electrochemical oxidation and reduction processes on ultrahigh vacuum prepared, smooth and structurally well-characterized Ru(0001) electrodes in a CO-saturated and, for comparison, in a CO-free flowing HClO4 electrolyte by electrochemical methods and by comparison with previous structural data. Structure and reactivity of the adsorbed layers are largely governed by a critical potential of E = 0.57 V, which determines the onset of Oad formation on the COad saturated surface in the positive-going scan and of Oadreduction in the negative-going scan. Oad formation proceeds via nucleation and 2D growth of high-coverage Oad islands in a surrounding COad phase, and it is connected with COadoxidation at the interface between the two phases. In the negative-going scan, mixed (COad + Oad) phases, most likely a (2 $\times$ 2)-(CO + 2O) and a (2$\times$2)-(2CO + O), are proposed to form at E $<$ 0.57 V by reduction of the Oad-rich islands and CO adsorption into the resulting lower-density Oad structures. CO bulk oxidation rates in the potential range E $>$ 0.57 V are low, but significantly higher than those observed during oxidation of pre-adsorbed CO in the CO-free electrolyte. We relate this to high local COad coverages due to CO adsorption in the CO-saturated electrolyte, which lowers the CO adsorption energy and thus the barrier for COadoxidation during CO bulk oxidation.",
    doi = "10.1039/C0CP01001D"
}

```