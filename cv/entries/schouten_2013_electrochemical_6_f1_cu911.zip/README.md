# schouten_2013_electrochemical_6_f1_cu911

A cyclic voltammogram for
Cu(911)
from Figure 1 in

K. J. P. Schouten et al. The electrochemical characterization of copper single-crystal electrodes in alkaline media. Journal of Electroanalytical Chemistry, 699:6–9, 2013

https://doi.org/10.1016/j.jelechem.2013.03.018

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/schouten_2013_electrochemical_6_f1_cu911/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `schouten_2013_electrochemical_6_f1_cu911.csv`: the digitized data.
* `schouten_2013_electrochemical_6_f1_cu911.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("schouten_2013_electrochemical_6_f1_cu911.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{schouten_2013_electrochemical_6,
    author = "Schouten, Klaas Jan P and Gallent, Elena Pérez and Koper, Marc TM",
    title = "The electrochemical characterization of copper single-crystal electrodes in alkaline media",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "699",
    pages = "6--9",
    year = "2013",
    publisher = "Elsevier",
    doi = "10.1016/j.jelechem.2013.03.018"
}

```