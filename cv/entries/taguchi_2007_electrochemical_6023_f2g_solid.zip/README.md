# taguchi_2007_electrochemical_6023_f2g_solid

A cyclic voltammogram for
Pt(221)
from Figure 2g in

S. Taguchi et al. Electrochemical reduction of nitrate on Pt (S)[n (111)×(111)] electrodes in perchloric acid solution. Electrochimica acta, 52(19):6023–6033, 2007

https://doi.org/10.1016/j.electacta.2007.03.057

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/taguchi_2007_electrochemical_6023_f2g_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `taguchi_2007_electrochemical_6023_f2g_solid.csv`: the digitized data.
* `taguchi_2007_electrochemical_6023_f2g_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("taguchi_2007_electrochemical_6023_f2g_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{taguchi_2007_electrochemical_6023,
    author = "Taguchi, Satoshi and Feliu, Juan M",
    title = "Electrochemical reduction of nitrate on Pt (S)[n (111)$\times$(111)] electrodes in perchloric acid solution",
    journal = "Electrochimica acta",
    volume = "52",
    number = "19",
    pages = "6023--6033",
    year = "2007",
    publisher = "Elsevier",
    doi = "10.1016/j.electacta.2007.03.057"
}

```