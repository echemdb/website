# sandbeck_2019_dissolution_2997_f1_solid_blue

A cyclic voltammogram for
Pt(100)
from Figure 1 in

D. J. Sandbeck et al. Dissolution of platinum single crystals in acidic medium. ChemPhysChem, 20(22):2997–3003, 2019

https://doi.org/10.1002/cphc.201900866

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/sandbeck_2019_dissolution_2997_f1_solid_blue/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `sandbeck_2019_dissolution_2997_f1_solid_blue.csv`: the digitized data.
* `sandbeck_2019_dissolution_2997_f1_solid_blue.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("sandbeck_2019_dissolution_2997_f1_solid_blue.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{sandbeck_2019_dissolution_2997,
    author = "Sandbeck, Daniel JS and Brummel, Olaf and Mayrhofer, Karl JJ and Libuda, Jörg and Katsounaros, Ioannis and Cherevko, Serhiy",
    title = "Dissolution of platinum single crystals in acidic medium",
    journal = "ChemPhysChem",
    volume = "20",
    number = "22",
    pages = "2997--3003",
    year = "2019",
    publisher = "Wiley Online Library",
    doi = "10.1002/cphc.201900866"
}

```