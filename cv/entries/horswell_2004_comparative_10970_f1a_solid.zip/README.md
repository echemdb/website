# horswell_2004_comparative_10970_f1a_solid

A cyclic voltammogram for
Ag(110)
from Figure 1a in

S. L. Horswell et al. A comparative study of hydroxide adsorption on the (111), (110), and (100) faces of silver with cyclic voltammetry, ex situ electron diffraction, and in situ second harmonic generation. Langmuir, 20(25):10970–10981, 2004

https://doi.org/10.1021/la0483818

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/horswell_2004_comparative_10970_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `horswell_2004_comparative_10970_f1a_solid.csv`: the digitized data.
* `horswell_2004_comparative_10970_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("horswell_2004_comparative_10970_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{horswell_2004_comparative_10970,
    author = "Horswell, Sarah L and Pinheiro, Alexei LN and Savinova, Elena R and Danckwerts, Matthias and Pettinger, Bruno and Zei, Mau-Scheng and Ertl, Gerhard",
    title = "A comparative study of hydroxide adsorption on the (111), (110), and (100) faces of silver with cyclic voltammetry, ex situ electron diffraction, and in situ second harmonic generation",
    journal = "Langmuir",
    volume = "20",
    number = "25",
    pages = "10970--10981",
    year = "2004",
    publisher = "ACS Publications",
    doi = "10.1021/la0483818"
}

```