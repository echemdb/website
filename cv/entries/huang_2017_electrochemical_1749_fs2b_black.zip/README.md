# huang_2017_electrochemical_1749_fs2b_black

A cyclic voltammogram for
Cu(111)
from Figure s2b in

Y. Huang et al. Electrochemical reduction of CO2 using copper single-crystal surfaces: effects of CO* coverage on the selective formation of ethylene. ACS Catalysis, 7(3):1749–1756, 2017

https://doi.org/10.1021/acscatal.6b03147

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/huang_2017_electrochemical_1749_fs2b_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `huang_2017_electrochemical_1749_fs2b_black.csv`: the digitized data.
* `huang_2017_electrochemical_1749_fs2b_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("huang_2017_electrochemical_1749_fs2b_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{huang_2017_electrochemical_1749,
    author = "Huang, Yun and Handoko, Albertus D and Hirunsit, Pussana and Yeo, Boon Siang",
    title = "Electrochemical reduction of CO2 using copper single-crystal surfaces: effects of CO* coverage on the selective formation of ethylene",
    journal = "ACS Catalysis",
    volume = "7",
    number = "3",
    pages = "1749--1756",
    year = "2017",
    publisher = "ACS Publications",
    doi = "10.1021/acscatal.6b03147"
}

```