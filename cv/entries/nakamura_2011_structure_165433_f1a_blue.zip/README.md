# nakamura_2011_structure_165433_f1a_blue

A cyclic voltammogram for
Ag(100)
from Figure 1a in

M. Nakamura et al. Structure of the electrical double layer on Ag(100): Promotive effect of cationic species on Br adlayer formation. Physical Review B, 84(16):165433, 2011

https://doi.org/10.1103/PhysRevB.84.165433

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/nakamura_2011_structure_165433_f1a_blue/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `nakamura_2011_structure_165433_f1a_blue.csv`: the digitized data.
* `nakamura_2011_structure_165433_f1a_blue.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("nakamura_2011_structure_165433_f1a_blue.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{nakamura_2011_structure_165433,
    author = "Nakamura, Masashi and Nakajima, Yo and Sato, Narumasa and Hoshi, Nagahiro and Sakata, Osami and others",
    title = "Structure of the electrical double layer on Ag(100): Promotive effect of cationic species on Br adlayer formation",
    journal = "Physical Review B",
    volume = "84",
    number = "16",
    pages = "165433",
    year = "2011",
    publisher = "APS",
    doi = "10.1103/PhysRevB.84.165433"
}

```