# hermann_2021_effect_138279_f5a_red

A cyclic voltammogram for
Au(111)
from Figure 5a in

J. M. Hermann et al. The Effect of pH and Anion Adsorption on Formic Acid Oxidation on Au(111) Electrodes. Electrochimica Acta, 385:138279, 2021

https://doi.org/10.1016/j.electacta.2021.138279

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/hermann_2021_effect_138279_f5a_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `hermann_2021_effect_138279_f5a_red.csv`: the digitized data.
* `hermann_2021_effect_138279_f5a_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("hermann_2021_effect_138279_f5a_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{hermann_2021_effect_138279,
    author = "Hermann, Johannes M. and Abdelrahman, Areeg and Jacob, Timo and Kibler, Ludwig A.",
    title = "The Effect of pH and Anion Adsorption on Formic Acid Oxidation on Au(111) Electrodes",
    journal = "Electrochimica Acta",
    volume = "385",
    pages = "138279",
    year = "2021",
    publisher = "Elsevier",
    issn = "0013-4686",
    doi = "10.1016/j.electacta.2021.138279",
    abstract = "The impact of solution pH has been investigated for the electrooxidation of formic acid on Au(111), taking the mole fraction of formate in solution as the relevant parameter. The electrocatalytic current density is increasing with rising pH and reaches a plateau for pH > 4. The pH-dependence of characteristic potentials shows systematic trends for the onset of the reaction, the peak maximum, and the phase transition within the formate adlayer. After the addition of phosphate buffer, a substantial deactivation by specific adsorption of phosphates and a bell-shaped curve for the maximum current density as a function of pH is found. The general behavior of co-adsorbing anions is addressed at low pH using various oxyanions to get more insight into the role of adsorbed formate. While non-carboxylate anions are displaced by formate at high potentials, mixed phases are observed for formate and other carboxylates."
}

```