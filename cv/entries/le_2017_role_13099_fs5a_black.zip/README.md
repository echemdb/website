# le_2017_role_13099_fs5a_black

A cyclic voltammogram for
Cu(100)
from Figure s5a in

C. S. Le Duff et al. Role of the adsorbed oxygen species in the selective electrochemical reduction of CO2 to alcohols and carbonyls on copper electrodes. Angewandte Chemie, 129(42):13099–13104, 2017

https://doi.org/10.1002/ange.201706463

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/le_2017_role_13099_fs5a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `le_2017_role_13099_fs5a_black.csv`: the digitized data.
* `le_2017_role_13099_fs5a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("le_2017_role_13099_fs5a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{le_2017_role_13099,
    author = "Le Duff, Cécile S and Lawrence, Matthew J and Rodriguez, Paramaconi",
    title = "Role of the adsorbed oxygen species in the selective electrochemical reduction of CO2 to alcohols and carbonyls on copper electrodes",
    journal = "Angewandte Chemie",
    volume = "129",
    number = "42",
    pages = "13099--13104",
    year = "2017",
    publisher = "Wiley Online Library",
    doi = "10.1002/ange.201706463"
}

```