# mello_2018_bromide_18562_f1h_black

A cyclic voltammogram for
Pt(111)
from Figure 1h in

G. A. Mello et al. Bromide Adsorption on Pt(111) over a Wide Range of pH: Cyclic Voltammetry and CO Displacement Experiments. The Journal of Physical Chemistry C, 122(32):18562–18569, 2018

https://doi.org/10.1021/acs.jpcc.8b05685

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/mello_2018_bromide_18562_f1h_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `mello_2018_bromide_18562_f1h_black.csv`: the digitized data.
* `mello_2018_bromide_18562_f1h_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("mello_2018_bromide_18562_f1h_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{mello_2018_bromide_18562,
    author = "Mello, Gisele AB and Briega-Martos, Valentin and Climent, Victor and Feliu, Juan M",
    title = "Bromide Adsorption on Pt(111) over a Wide Range of pH: Cyclic Voltammetry and CO Displacement Experiments",
    journal = "The Journal of Physical Chemistry C",
    volume = "122",
    number = "32",
    pages = "18562--18569",
    year = "2018",
    publisher = "ACS Publications",
    doi = "10.1021/acs.jpcc.8b05685"
}

```