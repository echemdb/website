# chen_2024_deconvolution_4958_f3b_black

A cyclic voltammogram for
Pt(100)
from Figure 3b in

X. Chen et al. Deconvolution of the Voltammetric Features of a Pt(100) Single-Crystal Electrode. The Journal of Physical Chemistry Letters, 15(18):4958–4964, 2024

https://doi.org/10.1021/acs.jpclett.4c01056

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/chen_2024_deconvolution_4958_f3b_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `chen_2024_deconvolution_4958_f3b_black.csv`: the digitized data.
* `chen_2024_deconvolution_4958_f3b_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("chen_2024_deconvolution_4958_f3b_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{chen_2024_deconvolution_4958,
    author = "Chen, Xiaoting and Ojha, Kasinath and Koper, Marc TM",
    title = "Deconvolution of the Voltammetric Features of a Pt(100) Single-Crystal Electrode",
    journal = "The Journal of Physical Chemistry Letters",
    volume = "15",
    number = "18",
    pages = "4958--4964",
    year = "2024",
    publisher = "ACS Publications",
    doi = "10.1021/acs.jpclett.4c01056"
}

```