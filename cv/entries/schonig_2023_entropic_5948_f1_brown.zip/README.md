# schonig_2023_entropic_5948_f1_brown

A cyclic voltammogram for
Au(111)
from Figure 1 in

M. Schönig et al. Entropic contributions to the stability of electrochemically adsorbed anion layers on Au(111): a microcalorimetric study. Physical Chemistry Chemical Physics, 25(8):5948–5954, 2023

https://doi.org/10.1039/D2CP04680F

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/schonig_2023_entropic_5948_f1_brown/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `schonig_2023_entropic_5948_f1_brown.csv`: the digitized data.
* `schonig_2023_entropic_5948_f1_brown.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("schonig_2023_entropic_5948_f1_brown.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{schonig_2023_entropic_5948,
    author = "Schönig, Marco and Schuster, Rolf",
    title = "Entropic contributions to the stability of electrochemically adsorbed anion layers on Au(111): a microcalorimetric study",
    journal = "Physical Chemistry Chemical Physics",
    volume = "25",
    number = "8",
    pages = "5948--5954",
    year = "2023",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/D2CP04680F"
}

```