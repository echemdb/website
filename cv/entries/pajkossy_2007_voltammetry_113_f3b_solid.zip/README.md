# pajkossy_2007_voltammetry_113_f3b_solid

A cyclic voltammogram for
Ir(100)
from Figure 3b in

T. Pajkossy et al. Voltammetry and impedance measurements of Ir(100) electrodes in aqueous solutions. Journal of Electroanalytical chemistry, 600(1):113–118, 2007

https://doi.org/10.1016/j.jelechem.2006.04.016

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/pajkossy_2007_voltammetry_113_f3b_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `pajkossy_2007_voltammetry_113_f3b_solid.csv`: the digitized data.
* `pajkossy_2007_voltammetry_113_f3b_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("pajkossy_2007_voltammetry_113_f3b_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{pajkossy_2007_voltammetry_113,
    author = "Pajkossy, Tamas and Kibler, Ludwig A and Kolb, Dieter M",
    title = "Voltammetry and impedance measurements of Ir(100) electrodes in aqueous solutions",
    journal = "Journal of Electroanalytical chemistry",
    volume = "600",
    number = "1",
    pages = "113--118",
    year = "2007",
    publisher = "Elsevier",
    doi = "10.1016/j.jelechem.2006.04.016"
}

```