# ando_1997_situ_277_f1a_solid

A cyclic voltammogram for
Co(0001)
from Figure 1a in

S. Ando et al. In situ electrochemical scanning tunneling microscopy of Co(0001) single crystal electrodes in acidic solution. Journal of Electroanalytical Chemistry, 431(2):277–284, 1997

https://doi.org/10.1016/S0022-0728(97)00208-8

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/ando_1997_situ_277_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `ando_1997_situ_277_f1a_solid.csv`: the digitized data.
* `ando_1997_situ_277_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("ando_1997_situ_277_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{ando_1997_situ_277,
    author = "Ando, Satoru and Suzuki, Takeshi and Itaya, Kingo",
    title = "In situ electrochemical scanning tunneling microscopy of Co(0001) single crystal electrodes in acidic solution",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "431",
    number = "2",
    pages = "277--284",
    year = "1997",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(97)00208-8"
}

```