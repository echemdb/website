# garcia-araez_2011_enthalpic_501_f1a_green

A cyclic voltammogram for
Pt(110)
from Figure 1a in

N. Garcia-Araez. Enthalpic and entropic effects on hydrogen and OH adsorption on Pt(111), Pt(100), and Pt(110) electrodes as evaluated by Gibbs thermodynamics. The Journal of Physical Chemistry C, 115(2):501–510, 2011

https://doi.org/10.1021/jp1088146

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/garcia-araez_2011_enthalpic_501_f1a_green/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `garcia-araez_2011_enthalpic_501_f1a_green.csv`: the digitized data.
* `garcia-araez_2011_enthalpic_501_f1a_green.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("garcia-araez_2011_enthalpic_501_f1a_green.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{garcia-araez_2011_enthalpic_501,
    author = "Garcia-Araez, Nuria",
    title = "Enthalpic and entropic effects on hydrogen and OH adsorption on Pt(111), Pt(100), and Pt(110) electrodes as evaluated by Gibbs thermodynamics",
    journal = "The Journal of Physical Chemistry C",
    volume = "115",
    number = "2",
    pages = "501--510",
    year = "2011",
    publisher = "ACS Publications",
    doi = "10.1021/jp1088146"
}

```