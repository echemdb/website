# meng_2012_hydrogen_5222_f1_red

A cyclic voltammogram for
Au(poly)
from Figure 1 in

Y. Meng et al. The hydrogen evolution reaction in a room temperature ionic liquid: mechanism and electrocatalyst trends. Physical Chemistry Chemical Physics, 14(15):5222–5228, 2012

https://doi.org/10.1039/c2cp23801b

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/meng_2012_hydrogen_5222_f1_red/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `meng_2012_hydrogen_5222_f1_red.csv`: the digitized data.
* `meng_2012_hydrogen_5222_f1_red.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("meng_2012_hydrogen_5222_f1_red.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{meng_2012_hydrogen_5222,
    author = "Meng, Yao and Aldous, Leigh and Belding, Stephen R and Compton, Richard G",
    title = "The hydrogen evolution reaction in a room temperature ionic liquid: mechanism and electrocatalyst trends",
    journal = "Physical Chemistry Chemical Physics",
    volume = "14",
    number = "15",
    pages = "5222--5228",
    year = "2012",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/c2cp23801b"
}

```