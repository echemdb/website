# briega-martos_2018_understandings_j3045_f1h_green

A cyclic voltammogram for
Pt(111)
from Figure 1h in

V. Briega-Martos et al. Understandings on the inhibition of oxygen reduction reaction by bromide adsorption on Pt(111) electrodes at different pH values. Journal of The Electrochemical Society, 165(15):J3045, 2018

https://doi.org/10.1149/2.0081815jes

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/briega-martos_2018_understandings_j3045_f1h_green/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `briega-martos_2018_understandings_j3045_f1h_green.csv`: the digitized data.
* `briega-martos_2018_understandings_j3045_f1h_green.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("briega-martos_2018_understandings_j3045_f1h_green.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{briega-martos_2018_understandings_j3045,
    author = "Briega-Martos, Valentín and Mello, Gisele AB and Arán-Ais, Rosa M and Climent, Víctor and Herrero, Enrique and Feliu, Juan M",
    title = "Understandings on the inhibition of oxygen reduction reaction by bromide adsorption on Pt(111) electrodes at different pH values",
    journal = "Journal of The Electrochemical Society",
    volume = "165",
    number = "15",
    pages = "J3045",
    year = "2018",
    publisher = "IOP Publishing",
    doi = "10.1149/2.0081815jes"
}

```