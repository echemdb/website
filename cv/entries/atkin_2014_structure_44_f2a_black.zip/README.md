# atkin_2014_structure_44_f2a_black

A cyclic voltammogram for
Au(111)
from Figure 2a in

R. Atkin et al. Structure and dynamics of the interfacial layer between ionic liquids and electrode materials. Journal of Molecular Liquids, 192:44–54, 2014

https://doi.org/10.1016/j.molliq.2013.08.006

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/atkin_2014_structure_44_f2a_black/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `atkin_2014_structure_44_f2a_black.csv`: the digitized data.
* `atkin_2014_structure_44_f2a_black.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("atkin_2014_structure_44_f2a_black.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{atkin_2014_structure_44,
    author = "Atkin, Rob and Borisenko, Natalia and Drüschler, Marcel and Endres, Frank and Hayes, Robert and Huber, Benedikt and Roling, Bernhard",
    title = "Structure and dynamics of the interfacial layer between ionic liquids and electrode materials",
    journal = "Journal of Molecular Liquids",
    volume = "192",
    pages = "44--54",
    year = "2014",
    publisher = "Elsevier",
    doi = "10.1016/j.molliq.2013.08.006"
}

```