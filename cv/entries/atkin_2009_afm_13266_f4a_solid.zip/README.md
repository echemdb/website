# atkin_2009_afm_13266_f4a_solid

A cyclic voltammogram for
Au(111)
from Figure 4a in

R. Atkin et al. AFM and STM studies on the surface interaction of [BMP] TFSA and [EMIm] TFSA ionic liquids with Au (111). The Journal of Physical Chemistry C, 113(30):13266–13272, 2009

https://doi.org/10.1021/jp9026755

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/atkin_2009_afm_13266_f4a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `atkin_2009_afm_13266_f4a_solid.csv`: the digitized data.
* `atkin_2009_afm_13266_f4a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("atkin_2009_afm_13266_f4a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{atkin_2009_afm_13266,
    author = "Atkin, Rob and El Abedin, Sherif Zein and Hayes, Robert and Gasparotto, Luiz HS and Borisenko, Natalia and Endres, Frank",
    title = "AFM and STM studies on the surface interaction of [BMP] TFSA and [EMIm] TFSA ionic liquids with Au (111)",
    journal = "The Journal of Physical Chemistry C",
    volume = "113",
    number = "30",
    pages = "13266--13272",
    year = "2009",
    publisher = "ACS Publications",
    doi = "10.1021/jp9026755"
}

```