# anjos_2010_underpotential_8_f1b_solid

A cyclic voltammogram for
Rh(100)
from Figure 1b in

D. Anjos et al. Underpotential deposition of copper and silver on single crystal surfaces of rhodium. Journal of Electroanalytical Chemistry, 639(1-2):8–14, 2010

https://doi.org/10.1016/j.jelechem.2009.10.003

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/anjos_2010_underpotential_8_f1b_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `anjos_2010_underpotential_8_f1b_solid.csv`: the digitized data.
* `anjos_2010_underpotential_8_f1b_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("anjos_2010_underpotential_8_f1b_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{anjos_2010_underpotential_8,
    author = "Anjos, DM and Rigsby, MA and Wieckowski, A",
    title = "Underpotential deposition of copper and silver on single crystal surfaces of rhodium",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "639",
    number = "1-2",
    pages = "8--14",
    year = "2010",
    publisher = "Elsevier",
    doi = "10.1016/j.jelechem.2009.10.003"
}

```