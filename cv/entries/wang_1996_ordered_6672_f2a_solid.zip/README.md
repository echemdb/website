# wang_1996_ordered_6672_f2a_solid

A cyclic voltammogram for
Au(110)
from Figure 2a in

J. Wang et al. Ordered binary ionic adlayers on a Au(110) electrode: Coadsorption of alkali metal cations with iodide anions. The Journal of Physical Chemistry, 100(16):6672–6677, 1996

https://doi.org/10.1021/jp952938y

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wang_1996_ordered_6672_f2a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wang_1996_ordered_6672_f2a_solid.csv`: the digitized data.
* `wang_1996_ordered_6672_f2a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wang_1996_ordered_6672_f2a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wang_1996_ordered_6672,
    author = "Wang, JX and Watson, GM and Ocko, BM",
    title = "Ordered binary ionic adlayers on a Au(110) electrode: Coadsorption of alkali metal cations with iodide anions",
    journal = "The Journal of Physical Chemistry",
    volume = "100",
    number = "16",
    pages = "6672--6677",
    year = "1996",
    publisher = "ACS Publications",
    doi = "10.1021/jp952938y"
}

```