# schnaidt_2017_combined_4166_f2_solid

A cyclic voltammogram for
Pt(111)
from Figure 2 in

J. Schnaidt et al. A combined UHV-STM-flow cell set-up for electrochemical/electrocatalytic studies of structurally well-defined UHV prepared model electrodes. Physical Chemistry Chemical Physics, 19(6):4166–4178, 2017

https://doi.org/10.1039/C6CP06051J

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/schnaidt_2017_combined_4166_f2_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `schnaidt_2017_combined_4166_f2_solid.csv`: the digitized data.
* `schnaidt_2017_combined_4166_f2_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("schnaidt_2017_combined_4166_f2_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{schnaidt_2017_combined_4166,
    author = "Schnaidt, Johannes and Beckord, Stephan and Engstfeld, Albert K and Klein, Jens and Brimaud, Sylvain and Behm, Rolf Jürgen",
    title = "A combined UHV-STM-flow cell set-up for electrochemical/electrocatalytic studies of structurally well-defined UHV prepared model electrodes",
    journal = "Physical Chemistry Chemical Physics",
    volume = "19",
    number = "6",
    pages = "4166--4178",
    year = "2017",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/C6CP06051J"
}

```