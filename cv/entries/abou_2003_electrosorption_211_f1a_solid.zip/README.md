# abou_2003_electrosorption_211_f1a_solid

A cyclic voltammogram for
Ag(100)
from Figure 1a in

I. Abou Hamad et al. Electrosorption of Br and Cl on Ag(100): experiments and computer simulations. Journal of Electroanalytical Chemistry, 554:211–219, 2003

https://doi.org/10.1016/S0022-0728(03)00178-5

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/abou_2003_electrosorption_211_f1a_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `abou_2003_electrosorption_211_f1a_solid.csv`: the digitized data.
* `abou_2003_electrosorption_211_f1a_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("abou_2003_electrosorption_211_f1a_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{abou_2003_electrosorption_211,
    author = "Abou Hamad, I and Wandlowski, Th and Brown, G and Rikvold, PA",
    title = "Electrosorption of Br and Cl on Ag(100): experiments and computer simulations",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "554",
    pages = "211--219",
    year = "2003",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(03)00178-5"
}

```