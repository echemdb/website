# engstfeld_2018_polycrystalline_17743_f4b_2

A cyclic voltammogram for
Cu(100)
from Figure 4b in

A. K. Engstfeld et al. Polycrystalline and single-crystal Cu electrodes: influence of experimental conditions on the electrochemical properties in alkaline media. Chemistry - A European Journal, 24(67):17743–17755, 2018

https://doi.org/10.1002/chem.201803418

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/engstfeld_2018_polycrystalline_17743_f4b_2/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `engstfeld_2018_polycrystalline_17743_f4b_2.csv`: the digitized data.
* `engstfeld_2018_polycrystalline_17743_f4b_2.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("engstfeld_2018_polycrystalline_17743_f4b_2.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{engstfeld_2018_polycrystalline_17743,
    author = "Engstfeld, Albert K and Maagaard, Thomas and Horch, Sebastian and Chorkendorff, Ib and Stephens, Ifan EL",
    title = "Polycrystalline and single-crystal Cu electrodes: influence of experimental conditions on the electrochemical properties in alkaline media",
    journal = "Chemistry - A European Journal",
    volume = "24",
    number = "67",
    pages = "17743--17755",
    year = "2018",
    abstract = "Single and polycrystalline Cu electrodes serve as model systems for the study of the electroreduction of CO2, CO and nitrate, or for corrosion studies; even so, there are very few reports combining electrochemical measurements with structural characterization. Herein both the electrochemical properties of polycrystalline Cu and single crystal Cu(1 0 0) electrodes in alkaline solutions (0.1 m KOH and 0.1 m NaOH) are investigated. It is demonstrated that the pre-treatment of the electrodes plays a crucial role in determining their electrochemical properties. Scanning tunneling microscopy, X-ray photoelectron spectroscopy and cyclic voltammetry are performed on Cu(1 0 0) electrodes prepared under UHV conditions; it is shown that the electrochemical properties of these atomically well-defined electrodes are distinct from electrodes prepared by other methods. Also highlighted is the significant role of residual oxygen and electrolyte convection in influencing the electrochemical properties.",
    doi = "10.1002/chem.201803418"
}

```