# hirai_2003_situ_329_f2_thick

A cyclic voltammogram for
Pb(111)
from Figure 2 in

N. Hirai et al. In situ EC-AFM observation with atomic resolution of Pb(100) and Pb(111) single crystals in sulfuric acid solution. Journal of power sources, 113(2):329–334, 2003

https://doi.org/10.1016/S0378-7753(02)00545-1

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/hirai_2003_situ_329_f2_thick/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `hirai_2003_situ_329_f2_thick.csv`: the digitized data.
* `hirai_2003_situ_329_f2_thick.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("hirai_2003_situ_329_f2_thick.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{hirai_2003_situ_329,
    author = "Hirai, Nobumitsu and Takeda, Kimiyoshi and Hara, Shigeta and Shiota, Masashi and Yamaguchi, Yoshiaki and Nakayama, Yasuhide",
    title = "In situ EC-AFM observation with atomic resolution of Pb(100) and Pb(111) single crystals in sulfuric acid solution",
    journal = "Journal of power sources",
    volume = "113",
    number = "2",
    pages = "329--334",
    year = "2003",
    publisher = "Elsevier",
    doi = "10.1016/S0378-7753(02)00545-1"
}

```