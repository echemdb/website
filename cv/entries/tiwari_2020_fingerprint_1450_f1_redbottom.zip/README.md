# tiwari_2020_fingerprint_1450_f1_redbottom

A cyclic voltammogram for
Cu(110)
from Figure 1 in

A. Tiwari et al. Fingerprint voltammograms of copper single crystals under alkaline conditions: a fundamental mechanistic analysis. The Journal of Physical Chemistry Letters, 11(4):1450–1455, 2020

https://doi.org/10.1021/acs.jpclett.9b03728

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/tiwari_2020_fingerprint_1450_f1_redbottom/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `tiwari_2020_fingerprint_1450_f1_redbottom.csv`: the digitized data.
* `tiwari_2020_fingerprint_1450_f1_redbottom.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("tiwari_2020_fingerprint_1450_f1_redbottom.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{tiwari_2020_fingerprint_1450,
    author = "Tiwari, Aarti and Heenen, Hendrik H and Bj{\o}rnlund, Anton Simon and Maagaard, Thomas and Cho, EunAe and Chorkendorff, Ib and Kristoffersen, Henrik H and Chan, Karen and Horch, Sebastian",
    title = "Fingerprint voltammograms of copper single crystals under alkaline conditions: a fundamental mechanistic analysis",
    journal = "The Journal of Physical Chemistry Letters",
    volume = "11",
    number = "4",
    pages = "1450--1455",
    year = "2020",
    publisher = "ACS Publications",
    doi = "10.1021/acs.jpclett.9b03728"
}

```