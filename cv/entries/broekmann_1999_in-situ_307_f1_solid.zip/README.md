# broekmann_1999_in-situ_307_f1_solid

A cyclic voltammogram for
Cu(111)
from Figure 1 in

P. Broekmann et al. In-situ STM investigation of specific anion adsorption on Cu(111). Journal of Electroanalytical Chemistry, 467(1-2):307–324, 1999

https://doi.org/10.1016/S0022-0728(99)00048-0

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/broekmann_1999_in-situ_307_f1_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `broekmann_1999_in-situ_307_f1_solid.csv`: the digitized data.
* `broekmann_1999_in-situ_307_f1_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("broekmann_1999_in-situ_307_f1_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{broekmann_1999_in-situ_307,
    author = "Broekmann, P and Wilms, M and Kruft, M and Stuhlmann, C and Wandelt, K",
    title = "In-situ STM investigation of specific anion adsorption on Cu(111)",
    journal = "Journal of Electroanalytical Chemistry",
    volume = "467",
    number = "1-2",
    pages = "307--324",
    year = "1999",
    publisher = "Elsevier",
    doi = "10.1016/S0022-0728(99)00048-0"
}

```