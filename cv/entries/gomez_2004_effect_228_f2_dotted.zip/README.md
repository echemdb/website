# gomez_2004_effect_228_f2_dotted

A cyclic voltammogram for
Pt(100)
from Figure 2 in

R. Gómez et al. Effect of temperature on hydrogen adsorption on Pt(111), Pt(110), and Pt(100) electrodes in 0.1 M HClO4. The Journal of Physical Chemistry B, 108(1):228–238, 2004

https://doi.org/10.1021/jp034982g

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/gomez_2004_effect_228_f2_dotted/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `gomez_2004_effect_228_f2_dotted.csv`: the digitized data.
* `gomez_2004_effect_228_f2_dotted.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("gomez_2004_effect_228_f2_dotted.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{gomez_2004_effect_228,
    author = "Gómez, Roberto and Orts, José M and Álvarez-Ruiz, Bernabé and Feliu, Juan M",
    title = "Effect of temperature on hydrogen adsorption on Pt(111), Pt(110), and Pt(100) electrodes in 0.1 M HClO4",
    journal = "The Journal of Physical Chemistry B",
    volume = "108",
    number = "1",
    pages = "228--238",
    year = "2004",
    publisher = "ACS Publications",
    doi = "10.1021/jp034982g"
}

```