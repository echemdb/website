# wang_2001_situ_2809_f2c_solid

A cyclic voltammogram for
Ru(0001)
from Figure 2c in

J. Wang et al. In situ X-ray reflectivity and voltammetry study of Ru(0001) surface oxidation in electrolyte solutions. The Journal of Physical Chemistry B, 105(14):2809–2814, 2001

https://doi.org/10.1021/jp0041757

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/wang_2001_situ_2809_f2c_solid/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `wang_2001_situ_2809_f2c_solid.csv`: the digitized data.
* `wang_2001_situ_2809_f2c_solid.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("wang_2001_situ_2809_f2c_solid.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{wang_2001_situ_2809,
    author = "Wang, JX and Marinković, NS and Zajonz, H and Ocko, BM and Adžić, RR",
    title = "In situ X-ray reflectivity and voltammetry study of Ru(0001) surface oxidation in electrolyte solutions",
    journal = "The Journal of Physical Chemistry B",
    volume = "105",
    number = "14",
    pages = "2809--2814",
    year = "2001",
    publisher = "ACS Publications",
    doi = "10.1021/jp0041757"
}

```