# gasparotto_2009_situ_11140_f1_dashed

A cyclic voltammogram for
Au(111)
from Figure 1 in

L. Gasparotto et al. In situ STM investigation of the lithium underpotential deposition on Au (111) in the air-and water-stable ionic liquid 1-butyl-1-methylpyrrolidinium bis (trifluoromethylsulfonyl) amide. Physical Chemistry Chemical Physics, 11(47):11140–11145, 2009

https://doi.org/10.1039/b916809e

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/gasparotto_2009_situ_11140_f1_dashed/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `gasparotto_2009_situ_11140_f1_dashed.csv`: the digitized data.
* `gasparotto_2009_situ_11140_f1_dashed.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("gasparotto_2009_situ_11140_f1_dashed.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{gasparotto_2009_situ_11140,
    author = "Gasparotto, LHS and Borisenko, N and Bocchi, N and El Abedin, S Zein and Endres, F",
    title = "In situ STM investigation of the lithium underpotential deposition on Au (111) in the air-and water-stable ionic liquid 1-butyl-1-methylpyrrolidinium bis (trifluoromethylsulfonyl) amide",
    journal = "Physical Chemistry Chemical Physics",
    volume = "11",
    number = "47",
    pages = "11140--11145",
    year = "2009",
    publisher = "Royal Society of Chemistry",
    doi = "10.1039/b916809e"
}

```