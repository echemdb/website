# nakamura_2014_structural_22136_f1a_inset

A cyclic voltammogram for
Ag(100)
from Figure 1a in

M. Nakamura et al. Structural dynamics of the electrical double layer during capacitive charging/discharging processes. The Journal of Physical Chemistry C, 118(38):22136–22140, 2014

https://doi.org/10.1021/jp506979p

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/nakamura_2014_structural_22136_f1a_inset/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `nakamura_2014_structural_22136_f1a_inset.csv`: the digitized data.
* `nakamura_2014_structural_22136_f1a_inset.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("nakamura_2014_structural_22136_f1a_inset.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{nakamura_2014_structural_22136,
    author = "Nakamura, Masashi and Kaminaga, Hiroto and Endo, Osamu and Tajiri, Hiroo and Sakata, Osami and Hoshi, Nagahiro",
    title = "Structural dynamics of the electrical double layer during capacitive charging/discharging processes",
    journal = "The Journal of Physical Chemistry C",
    volume = "118",
    number = "38",
    pages = "22136--22140",
    year = "2014",
    publisher = "ACS Publications",
    doi = "10.1021/jp506979p"
}

```