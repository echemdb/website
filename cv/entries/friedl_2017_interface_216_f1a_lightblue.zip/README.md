# friedl_2017_interface_216_f1a_lightblue

A cyclic voltammogram for
Au(111)
from Figure 1a in

J. Friedl et al. Interface between an Au(111) Surface and an Ionic Liquid: The Influence of Water on the Double-Layer Capacitance. ChemElectroChem, 4(1):216–220, 2017

https://doi.org/10.1002/celc.201600557

The data was curated by echemdb and is displayed at
https://www.echemdb.org/cv/entries/friedl_2017_interface_216_f1a_lightblue/

## Content

This archive contains a [frictionless Data Package](https://specs.frictionlessdata.io/data-package/):

* `friedl_2017_interface_216_f1a_lightblue.csv`: the digitized data.
* `friedl_2017_interface_216_f1a_lightblue.json`: the description of the data, i.e., the units of the columns and the metadata of the entry.
* `LICENSE.md`: the terms under which the data can be used.

The data is taken from release 0.10.0 of the
[electrochemistry-data](https://github.com/echemdb/electrochemistry-data) repository.

## Usage

The Data Package can be loaded with [unitpackage](https://echemdb.github.io/unitpackage/):

```python
from unitpackage.entry import Entry

entry = Entry.from_local("friedl_2017_interface_216_f1a_lightblue.json")
entry.df
```

## Citation

When using this data, please cite the original publication:

```bibtex
@article{friedl_2017_interface_216,
    author = "Friedl, Jochen and Markovits, Iulius IE and Herpich, Max and Feng, Guang and Kornyshev, Alexei A and Stimming, Ulrich",
    title = "Interface between an Au(111) Surface and an Ionic Liquid: The Influence of Water on the Double-Layer Capacitance",
    journal = "ChemElectroChem",
    volume = "4",
    number = "1",
    pages = "216--220",
    year = "2017",
    publisher = "Wiley Online Library",
    doi = "10.1002/celc.201600557"
}

```